import sys
import inspect
import os

import numpy as np

root = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
sys.path.insert(0, root + '/pycspd')
from cspd import CSPD as cr

def nap_wrapper(df):
    nap_bool = np.where(df["state"].to_numpy() == 0, True, False)   # 0 means awake

    # b1, b2, b3, b4, b5, b6, g1, g2, g3, g4, g5, g6, l1, l2, l3, l4, c1, c2, c3, a, bb, nt, lp, qt,nzt = [0.3926282123537868, 0.973726216816406, 0.6412124219518207, 0.06979307508732235, 0.5450946664202019, 0.9884188094422669, 0.37132795028895893, 0.1432054193228914, 0.701760011480025, 0.38437495589948734, 0.9183860823042017, 0.6479220057947142, 4.543733212486201, 18.890174446464872, 13.957756725136454, 4.793390507901703, 0.4795715360406394, 0.5805597857294332, 0.012428473364671828, 3.8381319041667505, 2.633529715744524, 6.592131249520484, 18.00761071873817, 0.02681760463120241, 0.9997753895348146]
    b1, b2, b3, b4, b5, b6, g1, g2, g3, g4, g5, g6, l1, l2, l3, l4, c1, c2, c3, a, bb, nt, lp, qt,nzt = [0.515387705140748, 0.1368182152155934, 0.2833030057430186, 0.9767388135080795, 0.6414219543156179, 0.020819747009962, 0.7481753894274739, 0.9964924902547526, 0.05265783544827686, 0.1464248884092994, 0.6641912735396098, 0.7919161220074059, 4.930033092546711, 3.9120572096034474, 15.94050372428606, 10.962941213073494, 0.7015156722371547, 0.2290212023098121, 0.10343716196493354, 1.9295818046503144, 0.9066224948419366, 5.733928826022829, 22.12513640657167, 0.10935805258701688, 0.7124802345986866]
        
    b = [b1, b2, b3, b4, b5, b6,]
    g = [g1, g2, g3, g4, g5, g6,]
    l = [l1, l2, l3, l4,]
    l = [int(round(le)) for le in l]
    lp = int(round(lp))
    c = [c1, c2, c3]

    cresp = cr(df["activity"].to_numpy()[nap_bool],
               df["datetime"].to_numpy()[nap_bool],
               a=a,
               b=bb,
               Lp=lp,
               )
    cresp.model(
                nap=True,
                nap_thresh=nt,
                y2_and=True,
                nap_zero_thresh=nzt,
                seq_filter=True,
                seq_min=7,
                aux_filt_size=30,
                quantile_threshold=qt,
                # verbose=True,
                candidate_search_time=45,
                ending_search=30,
                bt_points=b,
                gt_points=g,
                length_thresh=l,
                candidate_thresholds=c,
               )

    state = np.where(nap_bool,0,df["state"].to_numpy())
    state[nap_bool] = 7*(1-cresp.refined_output)   # 0 means awake and 1 means sleeping

    xzp = np.zeros(len(state))
    xzp[nap_bool] = cresp.xzp

    y20 = np.zeros(len(state))
    y20[nap_bool] = cresp.y20

    y21 = np.zeros(len(state))
    y21[nap_bool] = cresp.y21

    return state
