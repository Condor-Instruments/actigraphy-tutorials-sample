import sys
import inspect
import os

import numpy as np

root = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
sys.path.insert(0, root + '/pycrespo')
from crespo import Crespo as cr

def nap_wrapper(df):
    nap_bool = np.where(df["state"].to_numpy() == 0, True, False)   # 0 means awake

    # b1, b2, b3, b4, b5, b6, g1, g2, g3, g4, g5, g6, l1, l2, l3, l4, c1, c2, c3, t, a, bb, nt, lp, qt,nzt = [0.3926282123537868, 0.973726216816406, 0.6412124219518207, 0.06979307508732235, 0.5450946664202019, 0.9884188094422669, 0.37132795028895893, 0.1432054193228914, 0.701760011480025, 0.38437495589948734, 0.9183860823042017, 0.6479220057947142, 4.543733212486201, 18.890174446464872, 13.957756725136454, 4.793390507901703, 0.4795715360406394, 0.5805597857294332, 0.012428473364671828, 0.23840299315309466, 3.8381319041667505, 2.633529715744524, 6.592131249520484, 18.00761071873817, 0.02681760463120241, 0.9997753895348146]
    b1, b2, b3, b4, b5, b6, g1, g2, g3, g4, g5, g6, l1, l2, l3, l4, c1, c2, c3, t, a, bb, nt, lp, qt,nzt = [0.010367767003168327, 0.9933356149423122, 0.8904616978813272, 0.24090483131852447, 0.11645668655585001, 0.019027178669437636, 0.38704391014284034, 0.8528535161523669, 0.9755503922870874, 0.9152529611506856, 0.47699936546448873, 0.5833710240816307, 5.360694922400071, 2.2712279963763002, 7.572985627053603, 6.208994524740115, 0.23571282385385384, 0.4351377194292304, 0.31640528749333635, 0.1317982417604852, 1.9936121721961901, 0.7899571399937713, 3.1348774161095676, 22.96675785655118, 0.06770973537137681, 0.5041123320875991]
    
    b = [b1, b2, b3, b4, b5, b6,]
    g = [g1, g2, g3, g4, g5, g6,]
    l = [l1, l2, l3, l4,]
    l = [int(round(le)) for le in l]
    lp = int(round(lp))
    c = [c1, c2, c3]

    cresp = cr(df["activity"].to_numpy()[nap_bool],
               df["datetime"].to_numpy()[nap_bool],
               t=t,
               a=a,
               b=bb,
               Lp=lp,
               )
    cresp.model(
                nap=True,
                nap_thresh=nt,
                y2_and=True,
                nap_zero_thresh=nzt,
                seq_filter=False,
                aux_filt_size=30,
                quantile_threshold=qt,
                # verbose=True,
                candidate_search_time=45,
                ending_search=30,
                bt_points=b,
                gt_points=g,
                length_thresh=l,
                candidate_thresholds=c,
               )

    state = np.where(nap_bool,0,df["state"].to_numpy())
    state[nap_bool] = 7*(1-cresp.refined_output)   # 0 means awake and 1 means sleeping

    return state