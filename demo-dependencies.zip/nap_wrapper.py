import sys
import inspect
import os

import numpy as np

root = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
sys.path.insert(0, root + '/pycrespo')
from crespo import Crespo as cr

def nap_wrapper(df):
    nap_bool = np.where(df["state"].to_numpy() == 0, True, False)   # 0 means awake

    b1, b2, b3, b4, b5, b6, g1, g2, g3, g4, g5, g6, l1, l2, l3, l4, c1, c2, c3, t, a, bb, nt, lp, qt,nzt = [0.3926282123537868, 0.973726216816406, 0.6412124219518207, 0.06979307508732235, 0.5450946664202019, 0.9884188094422669, 0.37132795028895893, 0.1432054193228914, 0.701760011480025, 0.38437495589948734, 0.9183860823042017, 0.6479220057947142, 4.543733212486201, 18.890174446464872, 13.957756725136454, 4.793390507901703, 0.4795715360406394, 0.5805597857294332, 0.012428473364671828, 0.23840299315309466, 3.8381319041667505, 2.633529715744524, 6.592131249520484, 18.00761071873817, 0.02681760463120241, 0.9997753895348146]

    b = [b1, b2, b3, b4, b5, b6,]
    g = [g1, g2, g3, g4, g5, g6,]
    l = [l1, l2, l3, l4,]
    l = [int(round(le)) for le in l]
    lp = int(round(lp))
    c = [c1, c2, c3]

    cresp = cr(df["activity"].to_numpy()[nap_bool],
               df["datetime"].to_numpy()[nap_bool],
               t=t,
               a=a,
               b=bb,
               Lp=lp,
               )
    cresp.model(
                nap=True,
                nap_thresh=nt,
                y2_and=True,
                nap_zero_thresh=nzt,
                seq_filter=False,
                aux_filt_size=30,
                quantile_threshold=qt,
                # verbose=True,
                candidate_search_time=45,
                ending_search=30,
                bt_points=b,
                gt_points=g,
                length_thresh=l,
                candidate_thresholds=c,
               )

    state = np.where(nap_bool,0,df["state"].to_numpy())
    state[nap_bool] = 7*(1-cresp.refined_output)   # 0 means awake and 1 means sleeping

    return state