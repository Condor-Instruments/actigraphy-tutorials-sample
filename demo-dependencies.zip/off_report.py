import sys
import inspect
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, auc
import jax.numpy as jnp
from datetime import date,datetime,timedelta,time
from scipy.signal import find_peaks as peak

from functions import segmentation,zero_prop,below_prop


def off_report(offs,act,temp,temp_var,stamps,temp_thresh,act_thresh,extra=[],lumus=False,nbins=7,window=60,verbose=False,save=False,filename='off_report.csv'):
    n = len(act)
    off_report = pd.DataFrame(index=np.arange(len(offs)),columns=["start","end","len","zp","bp","act_s0","act_sn","act_bd","tv_s0","tv_sn","tv_bd"])

    zp_act = zero_prop(act)
    qt_act = zp_act + (1.0 - zp_act)*0.05
    low_act_thresh = np.quantile(act,qt_act,method="inverted_cdf")

    if len(stamps) < 1:
        start = datetime.today()
        stamps = [start + i*timedelta(minutes=1) for i in range(n)]

    if len(extra) > 0:
        if lumus:
            c1 = extra["c1"]
            c2 = extra["c2"]
            cdif = extra["cdif"]
            # off_report["c1m"] = 0.0
            # off_report["c2m"] = 0.0
            off_report["dcv"] = 0.0
        else:
            dif = extra["dif"]
            off_report["dtm"] = 0.0

    offnum = 0
    for off in offs:
        off_act = act[off[0]:off[1]]
        off_tv = temp_var[off[0]:off[1]]
        length = off[1]-off[0]

        act_segment = segmentation(off_act,nbins)
        tv_segment = segmentation(off_tv,nbins)

        off_report.at[offnum,"start"] = stamps[off[0]]
        if off[1] < n:
            off_report.at[offnum,"end"] = stamps[off[1]]
            off_report.at[offnum,"len"] = (stamps[off[1]] - stamps[off[0]]).total_seconds()/60.0
        else:
            off_report.at[offnum,"end"] = stamps[off[1]-1]
            off_report.at[offnum,"len"] = (stamps[off[1]-1] - stamps[off[0]]).total_seconds()/60.0
        off_report.at[offnum,"zp"] = zero_prop(off_act)

        if off[0] >= window:
            actb = 1-below_prop(act[off[0]-window:off[0]],act_thresh)
        else:
            actb = 1-below_prop(act[0:off[0]],act_thresh)
        off_report.at[offnum,"actb"] = actb

        if off[1]+window <= n:
            acta = 1-below_prop(act[off[1]:off[1]+window],act_thresh)
        else:
            acta = 1-below_prop(act[off[1]:n],act_thresh)
        off_report.at[offnum,"acta"] = acta

        # off_report.at[offnum,"actm"] = np.mean(off_act)
        off_report.at[offnum,"act_s0"] = act_segment[0]
        off_report.at[offnum,"act_sn"] = act_segment[nbins-1]
        # off_report.at[offnum,"tvm"] = np.mean(off_tv)
        off_report.at[offnum,"tv_s0"] = tv_segment[0]
        off_report.at[offnum,"tv_sn"] = tv_segment[nbins-1]
        off_report.at[offnum,"bp"] = below_prop(act[off[0]:off[1]],low_act_thresh)

        if len(extra) > 0:
            if lumus:
                off_c1 = c1[off[0]:off[1]]
                off_c2 = c2[off[0]:off[1]]
                off_cd = cdif[off[0]:off[1]]
                # off_report.at[offnum,"c1m"] = np.median(off_c1)
                # off_report.at[offnum,"c2m"] = np.median(off_c2)
                off_report.at[offnum,"dcv"] = np.var(off_cd)
            else:
                off_dif = dif[off[0]:off[1]]
                off_report.at[offnum,"dtm"] = np.median(off_dif)
                # off_report.at[offnum,"dtv"] = np.var(off_dif)

        offnum += 1
    off_report["act_bd"] = off_report["act_s0"] + off_report["act_sn"]
    off_report["tv_bd"] = off_report["tv_s0"] + off_report["tv_sn"]

    if verbose:
        print(off_report)

    if save:
        off_report.to_csv(path_or_buf="verbose/"+file+"_report.csv",sep=';',header=True,index_label=None,float_format="e")

    return off_report