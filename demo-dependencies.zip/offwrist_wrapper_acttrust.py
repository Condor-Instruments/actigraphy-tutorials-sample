import sys
import inspect
import os
import cProfile, pstats, io
import time as ttime

import pandas as pd
import numpy as np

from bimodal_thresh import bimodal_thresh
from offwrist_feature_bimodal import offwrist_feature_bimodal
from offwrist_refine_bimodal import offwrist_refine_bimodal
from sklearn.model_selection import ParameterGrid

from functions import *

# Numerical parameters for the algorithm
filt_hwl = 10
nbins = 100
min_cap_thresh = 0.02
off_qt = 0.25

# Parameters for the feature extraction step
varbs = ["signal","median"]
tvarbs = ["signal","var"]
c1varbs = None
c2varbs = None
half_window_length = np.array([filt_hwl])


# The following block of code are related to the optimized
# configuration. All parameters in the grid described in the
# next lines are related to the refinement step of the algo-
# rithm and were optimized using a mesh-grid.
param_grid = {
    "n_init":[5],
    "max_iter":[100],
    "tol":[1e-2],
    "border":[
              # "disc",
              "mod",
              # "mod2",
              # "act",
              # "temp"
              ],
    "dthresh":[False,],
    "just_bp":[True,],
    "filt_on":[True,],
    "act_filter":[False],
    "bp_thresh":[0.3],
    "act_bp_ft":[0.8],
    "skip_len_bp":[True,],
    # "off_qt":[0.25,0.05,0.1,0.15,0.2,],
    # "min_thresh":[0.02,0.01,0.015,0.025,0.03,0.04,0.05,],
    "off_qt":[0.15,],
    "min_thresh":[0.015,],
    "act_thresh_qt":[0.35,],
    "filt_hwl":[10],
    "last_len_filt":[True,],
    "length_thresh":[40],
    "ltv_filt":[False],
    "qt_method":["linear"],
    "act_bp_filt":[0.6],
    "always_search_peak":[False],
    "temp_var_q":[0.9],
    "quick_delete_start":[False],
    "bp_one_side":[False],
    "last_act_filt":[True],
    "report_filt":[False,True],
    "sleep_filter":[False,True],
    "dtm_filt":[False,True],
    "ltbfilt":[True,False],
    "short_slep_filt":[True,False],

    # "sleep_filt_hws":[120,240],
    # "sleep_conf":["all"],
    # "sleep_aqt":[0.3,0.4],
    # "sleep_zqt":[0.1],

    "sleep_filt_hws":[120,180,210,240],
    "sleep_conf":["both","all","zp"],
    "sleep_aqt":[0.3,0.35,0.4],
    "sleep_zqt":[0.05,0.1,0.15],
    }
param_grid = list(ParameterGrid(param_grid))

param_grid = [param for param in param_grid if ( (param["sleep_filter"] and ( ((param["ltbfilt"] == False) and ( 
                                                                                ((param["sleep_filt_hws"] == 120) and (param["sleep_aqt"] == 0.4) and (param["sleep_conf"] == "both") and (param["sleep_zqt"] == 0.05)) or
                                                                                ((param["sleep_filt_hws"] == 210) and (param["sleep_aqt"] == 0.3) and (param["sleep_conf"] == "all") and (param["sleep_zqt"] == 0.1)) 
                                                                            )) or ( param["ltbfilt"] and ( 
                                                                                ((param["sleep_filt_hws"] == 120) and (param["sleep_aqt"] == 0.4) and (param["sleep_conf"] == "zp") and (param["sleep_zqt"] == 0.1)) or
                                                                                ((param["sleep_filt_hws"] == 180) and (param["sleep_aqt"] == 0.3) and (param["sleep_conf"] == "all") and (param["sleep_zqt"] == 0.05)) 
                                                                                )
                                                                            )
)
                                                 ) or ((not param["sleep_filter"]) and (param["sleep_filt_hws"] == 120) and (param["sleep_conf"] == "all") and (param["sleep_aqt"] == 0.3) and (param["sleep_zqt"] == 0.1) and (param["ltbfilt"] == False) and (param["short_slep_filt"] == False))
                                             )
]


# Input DataFrame neccessary columns:  PIM, TEMPERATURE, EXT TEMPERATURE
def offwrist_wrapper_acttrust(df,verbose=False):
    # config = pd.read_csv(folder+"/offwrist_config.csv",sep=';',header=0,index_col=0)
    # config = config.at[0,"config"]

    config = 32 ## zero over_sleep configuration


    # Parametrization step
    param = param_grid[config]
    n_init = param["n_init"]
    max_iter = param["max_iter"]
    tol = param["tol"]
    border = param["border"]
    dthresh = param["dthresh"]
    just_bp = param["just_bp"]
    filt_on = param["filt_on"]
    act_filter = param["act_filter"]
    bp_thresh = param["bp_thresh"]
    act_bp_ft = param["act_bp_ft"]
    skip_len_bp = param["skip_len_bp"]
    off_qt = param["off_qt"]
    min_thresh = param["min_thresh"]
    act_thresh_qt = param["act_thresh_qt"]
    last_len_filt = param["last_len_filt"]
    filt_hwl = param["filt_hwl"]
    length_thresh = param["length_thresh"]
    ltv_filt = param["ltv_filt"]
    qt_method = param["qt_method"]
    act_bp_filt = param["act_bp_filt"]
    always_search_peak = param["always_search_peak"]
    temp_var_q = param["temp_var_q"]
    quick_delete_start = param["quick_delete_start"]
    last_act_filt = param["last_act_filt"]
    report_filt = param["report_filt"]
    sleep_filter = param["sleep_filter"]
    dtm_filt = param["dtm_filt"]
    ltbfilt = param["ltbfilt"]
    sleep_filt_hws = param["sleep_filt_hws"]
    sleep_conf = param["sleep_conf"]
    sleep_aqt = param["sleep_aqt"]
    sleep_zqt = param["sleep_zqt"]
    short_slep_filt = param["short_slep_filt"]

    data = df[df["TEMPERATURE"] > 0]
    if len(data) > 0:  # Asserting data validity
        extra = {"dif":np.absolute(np.subtract(df["TEMPERATURE"],df["EXT TEMPERATURE"]))}

        # Feature extraction from input data
        data = offwrist_feature_bimodal(data,half_window_length,varbs,tvarbs,c1varbs,c2varbs)

        # The first step is a thresholding operation using median activity
        act = data["activity_signal"].to_numpy()
        act_median_ = data["activity_median_w="+str(2*filt_hwl+1)].to_numpy()
        act_median = norm_01(act_median_)
        # The threshold is quantile-based
        zp = zero_prop(act_median)
        off_quantile = zp + off_qt*(1-zp)
        p = np.quantile(act_median,off_quantile,method='inverted_cdf')
        if p < min_cap_thresh:
            p = min_cap_thresh
        y3 = np.where(act_median < p,True,False)
        act_filt = y3.astype(int)

        
        # Second step is a thresholding operation using temperature
        temp = data["temperature_signal"].to_numpy()
        temp_ = norm_01(temp)
        temp_var = norm_01(data["temperature_var_w="+str(2*filt_hwl+1)].to_numpy())
        # The threshold is obtained using a Gaussian-kernel-estimation-based
        # algorithm
        temp_thresh, ash_d = bimodal_thresh(temp_[y3],verbose=verbose,nbins=nbins,n_init=n_init,max_iter=max_iter,tol=tol,dthresh=dthresh,)
        # Reverting the temperature normalization
        min_temp = np.min(temp) 
        max_temp = np.max(temp)
        temp_thresh = min_temp + temp_thresh*(max_temp - min_temp)
        y0 = np.where(temp < temp_thresh,True,False)

        # Lastly, the initial detection is refined using various custom techniques
        off_new = np.where(np.logical_and(y0,y3),0,1)        
        off_filt = offwrist_refine_bimodal(off_new,act,act_median_,temp,temp_var,temp_thresh,ash_d,act_filt,filt_hwl,False,extra,verbose=verbose,border=border,just_bp=just_bp,filt_on=filt_on,act_filter=act_filter,bp_thresh=bp_thresh,act_bp_ft=act_bp_ft,skip_len_bp=skip_len_bp,act_thresh_qt=act_thresh_qt,last_len_filt=last_len_filt,length_thresh=length_thresh,ltv_filt=ltv_filt,qt_method=qt_method,act_bp_filt=act_bp_filt,always_search_peak=always_search_peak,temp_var_q=temp_var_q,quick_delete_start=quick_delete_start,last_act_filt=last_act_filt,report_filt=report_filt,sleep_filter=sleep_filter,dtm_filt=dtm_filt,sleep_filt_hws=sleep_filt_hws,sleep_conf=sleep_conf,sleep_aqt=sleep_aqt,sleep_zqt=sleep_zqt,ltbfilt=ltbfilt,short_slep_filt=short_slep_filt)
        out = np.zeros(len(df)) 
        out[np.where(df["TEMPERATURE"] > 0,True,False)] = off_filt

    else:
        out = np.ones(len(df))
    
    return 4*(1.0-out)
