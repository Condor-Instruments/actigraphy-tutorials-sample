# -*- coding: utf-8 -*-

# Crespo algorithm class - 01/11/2019
# Julius Andretti

# References:
# [1] CRESPO, C.; ABOY, M.; FERNÁNDEZ, J. R.; MOJÓN, A.: Automatic identification of activity-rest periods based on actigraphy (2012)

from scipy.stats import mode
import numpy as np
import time
import matplotlib.pyplot as plt
import pandas as pd
from datetime import datetime, timedelta
from scipy.ndimage import binary_closing, binary_opening
from scipy.signal import find_peaks as peak
from crespo_functions import *

# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)
# pd.set_option('display.width', None)
# pd.set_option('display.max_colwidth', None)
    
class Crespo:
    def __init__(self,
                 activity,
                 time_index,
                 csi=15,csi_a=2,csi_r=30,
                 t=0.33,
                 a=8,
                 b=1,
                 sleep_quantil=1/3,
                 Lp=61,
                 ):
            
    # activity is the input activity array
    # time_index is a datetime array containing the actigraphy timestamps
    # csi is the threshold for consecutive zeroes
    # csi_a is the threshold for consecutive zeroes inside wake periods
    # csi_r is the threshold for consecutive zeroes inside sleep periods
    # t is the percentile chosen to minimize the effect of invalid zeroes during preprocessing
    # a is the length in hours of the preprocessing np.median filter
    # b is the length in hours of the padding added prior to adaptive median filter
    # sleep_quantil is the average number of hours of sleep
    # Lp is the window length for the preprocessing morphological filter

        if not isinstance(time_index[0],datetime):
            if isinstance(time_index[0],str):
                time_index = pd.to_datetime(time_index,dayfirst=True)
            
            time_index = np.array([to_datetime(stamp) for stamp in time_index])

        self.interval = mode(datetime_diff(time_index)).mode[0]

        self.time_index = time_index
        n = len(time_index)

        self.invalid_input = False
        if (
            (self.interval > 120)
            or 
            (((self.time_index[n-1] - self.time_index[0]).total_seconds()) < 3600)
            ):
            self.invalid_input = True

        self.activity = (1.0/self.interval)*np.array(activity)
        self.csi = csi
        self.csi_a = csi_a
        self.csi_r = csi_r
        self.t = t
        self.a = a
        self.b = b
        self.sleep_quantil = sleep_quantil
        self.Lp = Lp
    
    def model(self,
              nap=False,
              nap_thresh=2,
              nap_min=20,
              y2_and=False,
              nap_zero_thresh=0.5,
              last_morph=False,
              seq_filter=True,
              aux_filt_size=45,
              quantile_threshold=0.6,
              seq_min=15,
              refine_median_window=4,
              condition=0,
              metric_choice=1,
              fraction=0.5,
              gap_thresh=10,
              bt_points=[0.233528, 0.459746, 0.000522996, 0.718822, 0.558178, 0.350738,],
              gt_points=[0.831343, 0.139121, 0.117863, 0.443673, 0.339229, 0.407142,],
              length_thresh=[8,18,18,17],
              candidate_thresholds=[0.210611, 0.210611, 0.715025],
              refine_median_diff_window = 3,
              candidate_search_time = 90,
              ending_search = 60,
              median_search = 3,
              peak_hws = 10,
              verbose=False,
              ):
    
        # If last_morph==True, the last morphological operation is applied

        ### Refinement stage parameters
        # metric_choice defines wich metric will be used in the median filter thresholding operation
        # refine_median_window is the length in minutes of the half-window to be used in the median filter
        # median_excursion_threshold is the maximum excursion of the median for a bedtime refinement window to be considered valid
        # fraction is a float between 0 and 1 used to set the metric threshold
        # refine_median_diff_window   # Median difference (derivative) filter window [minutes]
        # candidate_search_time   # Defines the above mentioned "after", a window after the candidate [minutes]
        # ending_search   # Defines a window after the current ending of the bedtime refinement interval [minutes]
        # median_search   # Used to define a median evaluation window to determine refinement interval border [minutes]
        # peak_hws   # Half-window to search for peaks during refinement [minutes]

        n = len(self.activity)   # Number of points

        nb = np.array([],dtype=int)   # Refined bed times indexes array
        ng = np.array([],dtype=int)   # Refined wakeup times indexes array

        if not self.invalid_input:
            minimum_quantile_threshold = 1
            
            Lw = int(60*self.a)+1    # Filter window length
            Lwo2 = int((Lw-1)/2)    # Filter half-window length

            m = max(self.activity)

            if not nap:
                x = self.activity.copy()   # Conditioned signal (invalid zeroes effect minimized)
                
                st = np.quantile(self.activity,self.t,interpolation='linear')   # Value of percentile t
                mask = np.ones(n)   # mask[i]==0 if i is the index of an invalid zero
                zero_len = 0
                for i in range(n):
                    if self.activity[i] == 0.0:
                        zero_len += 1

                    else:
                        if zero_len > self.csi:   # Sequences of more than csi consecutive zeroes are invalid
                            x[i-zero_len:i] = st
                            mask[i-zero_len:i] = 0

                        zero_len = 0

                # x is then padded at the beggining and at the end with a sequence of 30*a elements of value m=max(activity)
                pad = m*np.ones(int(30*self.a))
                xf = np.insert(x,0,pad)
                xf = np.append(xf,pad)
                xf = median_filter(xf,Lwo2,padding='padded')

                p = np.quantile(xf,self.sleep_quantil,interpolation='linear')
                y1 = np.where(xf > p, 1, 0)    # Thresholding operation
                
                strel = np.ones(self.Lp)   # Morphological strutcturing element
                ye = binary_opening(binary_closing(y1,strel),strel).astype(int)   # Morphological operations

                invalid = np.asanyarray([],dtype=int) # This array will contain the indexes of the invalid zeroes
                zero_a = 0
                zero_r = 0
                mask = np.ones(n)   # mask[i]==0 if i is the index of an invalid zero
                for i in range(n):
                    if ye[i]:   # If classified as wake
                        if zero_r > self.csi_r:
                            invalid = np.append(invalid,range(i-zero_r,i))
                            mask[i-zero_r:i] = 0
                        zero_r = 0

                        if self.activity[i] == 0:
                            zero_a += 1
                        
                        else:
                            if zero_a > self.csi_a:
                                invalid = np.append(invalid,range(i-zero_a,i))
                                mask[i-zero_a:i] = 0
                            zero_a = 0

                    else:   # If classified as sleep
                        if zero_a > self.csi_a:
                            invalid = np.append(invalid,range(i-zero_a,i))
                            mask[i-zero_a:i] = 0
                        zero_a = 0
                        
                        if self.activity[i] == 0:
                            zero_r += 1
                        
                        else:
                            if zero_r > self.csi_r:
                                invalid = np.append(invalid,range(i-zero_r,i))
                                mask[i-zero_r:i] = 0
                            zero_r = 0

            # Input array padded at the beggining and at the end with a sequence of m-valued elements with length of b hours 
            pad_size = int(60*self.b)

            xsp = self.activity.copy()
            pad = m*np.ones(pad_size)
            xsp = np.insert(xsp,0,pad)
            xsp = np.append(xsp,pad)

            xfa = np.zeros(n)

            # Now let's apply an adaptive median filter

            ws_min = pad_size   # Minimum half-window size
            ws_max = Lwo2   # Maximum half-window size
            grow_then_shrink = True   # If True, window size progressively increases and then progressively decreases
                                      # If False, window size is constant and equal to ws_max

            ws = ws_max
            if grow_then_shrink:
                ws = ws_min

            if not nap:
                invalid = np.array(invalid)+pad_size   # Move invalid indexes to match the ones in the padded array
                xsp[invalid] = np.nan   # Invalid points are marked as NaN

            for i in range(n):
                center = i+pad_size   # Median center

                xfa[i] = np.nanmedian(xsp[center-ws:center+ws+1])   # Take the median in desired window ignoring NaN values
                if np.isnan(xfa[i]):
                    if i > 0:
                        j = i-1
                        while np.isnan(xfa[j]):
                            if j > 0:
                                j -= 1
                        xfa[i] = xfa[j]
                    else:
                        xfa[i] = 0

                if grow_then_shrink:
                    # Progressive increase and decrease is implemented to maintain a symmetric window around the current sample at the points
                    # where the distance from the current sample to the end_m of the padded is less than half of the maximum window length

                    if (i < (n-ws_max+ws_min-1)):   # Closer to the beginning of the signal
                        if (ws < ws_max):   # Window grows
                            ws += 1

                    else:   # Closer to the end_m of the signal
                        if (ws > ws_min):   # Window shrinks
                            ws -= 1            

            if not nap:
                p = np.quantile(xfa, self.sleep_quantil, interpolation='linear')
                if p < minimum_quantile_threshold:
                    p = minimum_quantile_threshold
                    condition = 2

                if condition == 2:
                    quantile_threshold *= 1.333

                y2 = np.where(xfa > p, 1, 0)    # New thresholding operation

            else:
                xzp = zero_prop_filter(self.activity,5)

                y20 = np.where(xzp > nap_zero_thresh, True, False)
                y21 = np.where(xfa < nap_thresh, True, False)

                if y2_and:
                    y2 = np.where(np.logical_and(y20,y21),0,1)
                else:
                    y2 = np.where(np.logical_or(y20,y21),0,1)
            
            # New morphological structuring element
            Lpp = 2*(self.Lp - 1) + 1
            strel = np.ones(Lpp)
            
            output = y2.copy()
            if last_morph:   # Last morphological operation
                output = binary_opening(binary_closing(y2,strel),strel).astype(int)

            # bt_last   # points for being the last
            # bt_diff   # points for smallest median diff
            # bt_cross    # points for being close to xf crossing
            # bt_aux    # points for having smallest sum (no thresholded)
            # bt_threshamp   # thresholded candidate max points
            # bt_threshmin   # thresholded candidate bonus points
            bt_last,bt_diff,bt_cross,bt_aux,bt_threshamp,bt_threshmin = bt_points

            # gt_first   # points for being the first
            # gt_diff   # points for largest median diff
            # gt_cross   # points for being close to xf crossing
            # gt_aux   # points for having smallest sum (no thresholded)
            # gt_threshamp   # thresholded candidate max points
            # gt_threshmin   # thresholded candidate bonus points
            gt_first,gt_diff,gt_cross,gt_aux,gt_threshamp,gt_threshmin = gt_points

            # bt_p_length_thresh   # Minimal length for valid peaks in bedtime interval [minutes]
            # bt_v_length_thresh   # Minimal length for valid valleys in bedtime interval [minutes]
            # gt_p_length_thresh   # Minimal length for valid peaks in getup time interval [minutes]
            # gt_v_length_thresh   # [Minimal length for valid valleys in getup time interval minutes]
            bt_p_length_thresh,bt_v_length_thresh,gt_p_length_thresh,gt_v_length_thresh = np.array(length_thresh).astype(int)

            # candidate_max_over_thershold_proportion   # Maximum proportion of epochs above defined threshold that are allowed "after" a valid bedtime candidate
            # zero_proportion_threshold      # Minimal proportion of zeros required at the end of the bedtime refinement interval 
            candidate_max_over_thershold_proportion_bt,candidate_max_over_thershold_proportion_gt,zero_proportion_threshold = candidate_thresholds

            if condition == 2:
                zero_proportion_threshold *= 0.666

            # Minutes to epochs conversion
            bt_p_length_thresh = int(round(bt_p_length_thresh*60/self.interval))
            bt_v_length_thresh = int(round(bt_v_length_thresh*60/self.interval))
            gt_p_length_thresh = int(round(gt_p_length_thresh*60/self.interval))
            gt_v_length_thresh = int(round(gt_v_length_thresh*60/self.interval))
            candidate_search_time = int(round(candidate_search_time*60/self.interval))
            candidate_max_over_thershold_bt = int(round(candidate_search_time*candidate_max_over_thershold_proportion_bt))
            candidate_max_over_thershold_gt = int(round(candidate_search_time*candidate_max_over_thershold_proportion_gt))
            ending_search = int(round(ending_search*60/self.interval))
            median_search = int(round(median_search*60/self.interval))
            mws = int(round(refine_median_window*60/self.interval))
            mdfs = int(round(refine_median_diff_window*60/self.interval))
            peak_hws = int(round(peak_hws*60/self.interval))
            seq_min = int(round(seq_min*60/self.interval))
            gap_thresh = gap_thresh*self.interval
            aux_filt_size = int(aux_filt_size*60/self.interval)

            xf_aux = median_filter(self.activity,aux_filt_size,padding='same')
            quantile_threshold = np.quantile(xf_aux, quantile_threshold, interpolation='linear')

            xf_min = 3

            # Sequences of zeros are filtered if they aren't long enough
            if seq_filter:
                base_transitions = make_transitions_df(self.activity,output,0.5,False)
                # print("base_transitions\n",base_transitions)

                num_transitions_window = len(base_transitions)

                if (base_transitions.at[0,"length"] <= seq_min):
                    start = int(base_transitions.at[0,"start"])
                    end = int(base_transitions.at[1,"end"])

                    base_transitions.at[1,"start"] = start

                    slice_len = end-start
                    base_transitions.at[1,"length"] = slice_len

                    base_transitions.drop(index=[0],inplace=True)
                    num_transitions_window = len(base_transitions)
                    base_transitions.index = range(num_transitions_window)

                    # print("base_transitions\n",base_transitions)

                t = 1
                while (t < num_transitions_window):
                    remove = False
                    # All transitions are subjected to length-based thresholding and, if not filtered, they are evaluated based off other criteria

                    if (base_transitions.at[t,"length"] <= seq_min):
                        remove = True

                    if remove:
                        # Transition filtering process takes place
                        start = int(base_transitions.at[t-1,"start"])

                        if t < num_transitions_window-1:
                            end = int(base_transitions.at[t+1,"end"])
                            base_transitions.drop(index=[t,t+1],inplace=True)

                        else:
                            end = int(base_transitions.at[t,"end"])
                            base_transitions.drop(index=[t],inplace=True)

                        base_transitions.at[t-1,"end"] = end

                        slice_len = end-start
                        base_transitions.at[t-1,"length"] = slice_len

                        num_transitions_window = len(base_transitions)
                        base_transitions.index = range(num_transitions_window)

                    else:
                        t += 1


                output = np.ones(n)
                num_transitions_window = len(base_transitions)
                t = 0
                while (t < num_transitions_window):
                    if (base_transitions.at[t,"class"] == "v"):
                        output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
                    t += 1


            edges = np.diff(output)
            edges_index = edges.nonzero()[0]  # Output edges

            transitions = [[i,edges[i]] for i in edges_index]   # Transitions order and starting epoch
            refined_transitions = transitions.copy()
            num_transitions = len(transitions)

            def get_key0(item):
                return item[0]

            def get_key2(item):
                return item[2]        
            
            if condition == 1:
                median_excursion_threshold *= 3.5

            edge_median = np.zeros(n)
            edge_levels = np.zeros(n)
            edge_metric = np.zeros(n)
            edge_fourier = np.zeros(n)
            edge_median_diff = np.zeros(n)

            if num_transitions > 0: # Transitions are refined sequentially
                refined_output = np.zeros(n)

                i = 0
                while i < num_transitions:
                    index = transitions[i][0]

                    if i-1 >= 0:
                        previous_transition = refined_transitions[i-1][0]
                    else:
                        previous_transition = 0

                    if i+1 < num_transitions:
                        next_transition = refined_transitions[i+1][0]
                    else:
                        next_transition = n+1

                    if transitions[i][1] < 0:   # Bedtime refinement
                        start_m = index-1
                        if start_m < 0:
                            start_m = 0

                        no_gap = True
                        td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')                    
                        if td > gap_thresh:
                            no_gap = False

                        if start_m >= xf_min:
                            hi_xf = xf_aux[start_m-xf_min:start_m] 
                        else:
                            hi_xf = xf_aux[0:start_m] 

                        hi_xf = np.where(hi_xf > quantile_threshold,1,0)
                        sum_min = len(hi_xf)

                        while (   # Boundary conditions for the beggining of the bedtime refinement interval
                                   (start_m > 0) and
                                   (start_m-1 > previous_transition) and 
                                   no_gap and
                                   (np.sum(hi_xf) < sum_min)
                              ):
                            start_m -= 1   # Interval is stretched to the left
                            # print("bt start_m",start_m)

                            if start_m > 0:
                                td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')
                                if td > gap_thresh:
                                    no_gap = False

                            if start_m >= xf_min:
                                hi_xf = xf_aux[start_m-xf_min:start_m] 
                            else:
                                hi_xf = xf_aux[0:start_m] 

                            hi_xf = np.where(hi_xf > quantile_threshold,1,0)
                            sum_min = len(hi_xf)
                        
                        end_m = index + 1

                        if ((end_m+ending_search) < n):
                            ending_end = end_m+ending_search+1
                        else:
                            ending_end = n

                        if ((end_m-ending_search) > 0):
                            ending_start = end_m-ending_search
                        else:
                            ending_start = 0
                        
                        ending = self.activity[ending_start:ending_end]
                        zero_proportion = np.sum(np.where(ending == 0,1,0))/(ending_end-ending_start)

                        no_gap = True
                        td = pd.Timedelta(self.time_index[end_m]-self.time_index[end_m-1])/np.timedelta64(1,'s')
                        if td > gap_thresh:
                            
                            no_gap = False


                        # print(start_m,end_m)
                        if start_m-mws >= 0:
                            if end_m+mws+1 <= n:
                                median_vec = self.activity[start_m-mws:end_m+mws+1]
                            else:
                                median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                        else:
                            median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                        median = median_filter(median_vec,mws,padding='padded')

                        mean = 0
                        metric = 0
                        median_over_zero = median[np.where(median > 0)]
                        if len(median_over_zero) > 0:
                            mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                            if metric_choice == 1:
                                fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                metric = fraction_mean
                            elif metric_choice == 2:
                                p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                metric = p

                        median_ending = median[len(median)-median_search:len(median)]

                        while (   # Boundary conditions for the end of the bedtime refinement interval
                                    (end_m+1 < n) and
                                    (end_m+1 < next_transition) and
                                    no_gap and
                                    (
                                        (zero_proportion < zero_proportion_threshold)  or
                                        (np.sum(np.where(median_ending >= metric,1,0)) > 0)
                                    )
                              ):
                            end_m += 1   # Interval is stretched to the right
                            # print("bt end",end_m)

                            if ((end_m+ending_search) < n):
                                ending_end = end_m+ending_search+1
                            else:
                                ending_end = n

                            if ((end_m-ending_search) > 0):
                                ending_start = end_m-ending_search
                            else:
                                ending_start = 0
                            
                            ending = self.activity[ending_start:ending_end]
                            zero_proportion = np.sum(np.where(ending == 0,1,0))/(ending_end-ending_start)

                            td = pd.Timedelta(self.time_index[end_m]-self.time_index[end_m-1])/np.timedelta64(1,'s')
                            if td > gap_thresh:
                                
                                no_gap = False

                            if start_m-mws >= 0:
                                if end_m+mws+1 <= n:
                                    median_vec = self.activity[start_m-mws:end_m+mws+1]
                                else:
                                    median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                            else:
                                median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                            median = median_filter(median_vec,mws,padding='padded')
                            mean = 0
                            metric = 0
                            median_over_zero = median[np.where(median > 0)]
                            if len(median_over_zero) > 0:
                                mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                                if metric_choice == 1:
                                    fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                    metric = fraction_mean
                                elif metric_choice == 2:
                                    p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                    metric = p

                            median_ending = median[len(median)-median_search:len(median)]


                        no_gap = True
                        td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')
                        if td > gap_thresh:
                            
                            no_gap = False

                        median_ending = median[0:median_search]

                        while (   # Boundary conditions for the beggining of the bedtime refinement interval
                                   (start_m > 0) and
                                   (start_m-1 > previous_transition) and 
                                   no_gap and
                                   (np.sum(np.where(median_ending < metric,1,0)) > 0)
                              ):
                            start_m -= 1   # Interval is stretched to the left
                            # print("bt start2",start_m)

                            if start_m > 0:
                                td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')
                                if td > gap_thresh:
                                    
                                    no_gap = False
                                
                            if start_m-mws >= 0:
                                if end_m+mws+1 <= n:
                                    median_vec = self.activity[start_m-mws:end_m+mws+1]
                                else:
                                    median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                            else:
                                median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                            median = median_filter(median_vec,mws,padding='padded')
                            mean = 0
                            median_over_zero = median[np.where(median > 0)]
                            if len(median_over_zero) > 0:
                                mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                                if metric_choice == 1:
                                    fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                    metric = fraction_mean
                                elif metric_choice == 2:
                                    p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                    metric = p

                            median_ending = median[0:median_search]

                        if start_m-mws >= 0:
                            if end_m+mws+1 <= n:
                                median_vec = self.activity[start_m-mws:end_m+mws+1]
                            else:
                                median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                        else:
                            median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                        median = median_filter(median_vec,mws,padding='padded')
                        # Choice of metric
                        mean = 0
                        metric = 0
                        median_over_zero = median[np.where(median > 0)]
                        if len(median_over_zero) > 0:
                            mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                            if metric_choice == 1:
                                fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                metric = fraction_mean
                            elif metric_choice == 2:
                                p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                metric = p

                        dt_diff = datetime_diff(time_index[start_m:end_m+1])
                        if np.max(dt_diff) >= gap_thresh:
                            start_m = start_m + np.argmax(dt_diff)

                        # Median difference computation
                        median_diff = np.diff(median)
                        smooth_median_diff = median_filter(median_diff,mws,padding='same')
                      
                        window = self.activity[start_m:end_m+1]    # Raw activity in the refinement interval
                        transitions_df = make_transitions_df(window,median,metric,True)   # Transitions relative to the median filter and chosen metric

                        if verbose:
                            print("\n\n\nbed time refinement")
                            print("metric",metric)
                            print("transitions_df\n",transitions_df)

                        # Transitions are evaluated and may be filtered out
                        num_transitions_window = len(transitions_df)
                        if ((num_transitions_window > 2) and (num_transitions_window != 3)):
                            # First transition is treated separately
                            if (transitions_df.at[0,"class"] == "v"):   # But only if it is classified as a valley
                                if (transitions_df.at[0,"length"] < bt_v_length_thresh):   # Length-based thresholding
                                    # Transition filtering process takes place
                                    start = int(transitions_df.at[0,"start"])
                                    end = int(transitions_df.at[1,"end"])

                                    transitions_df.at[0,"end"] = end

                                    sliced = window[start:end]

                                    slice_len = end-start
                                    transitions_df.at[0,"length"] = slice_len

                                    slice_mean = np.mean(sliced)
                                    transitions_df.at[0,"mean"] = slice_mean

                                    slice_median = np.median(sliced)
                                    transitions_df.at[0,"median"] = slice_median

                                    slice_zeros = np.sum(np.where(sliced == 0,1,0))/(end-start)
                                    transitions_df.at[0,"zero_proportion"] = slice_zeros

                                    slice_abvm = np.sum(np.where(sliced > metric,1,0))/(end-start)
                                    transitions_df.at[0,"abvm_proportion"] = slice_abvm

                                    transitions_df.at[0,"class"] = "p"

                                    transitions_df.drop(index=[1],inplace=True)
                                    num_transitions_window = len(transitions_df)
                                    transitions_df.index = range(num_transitions_window)

                            t = 1
                            while (t < num_transitions_window) and ((num_transitions_window > 2) and (num_transitions_window != 3)):
                                remove = False
                                # print("bt t",t)
                                # All transitions are subjected to length-based thresholding and, if not filtered, they are evaluated based off other criteria

                                if (transitions_df.at[t,"class"] == "p"):
                                    if (transitions_df.at[t,"length"] < bt_p_length_thresh):
                                        # remove = True

                                        if (
                                             (t < num_transitions_window-2) and 
                                             (transitions_df.at[t+1,"length"] < bt_v_length_thresh)
                                           ):    # Bedtime peaks with invalid lengths are spared if they're right before a valley with invalid length
                                            pass
                                        else:
                                            remove = True

                                    else:
                                        if (transitions_df.at[t,"mean"] <= 1.33*metric):   # Bedtime peaks with valid lengths are removed if their mean is small
                                            remove = True

                                        elif (
                                              (condition == 2) and 
                                              (
                                               (t > 0) and 
                                               (transitions_df.at[t-1,"length"] >= 15*transitions_df.at[t,"length"])
                                              )
                                             ):
                                            remove = True


                                else:#(transitions_df.at[t,"class"] == "v")
                                    if (t < num_transitions_window-1):
                                        if (transitions_df.at[t,"length"] < bt_v_length_thresh):
                                            remove = True

                                        else:
                                            remove_points = 0
                                            if (transitions_df.at[t,"abvm_proportion"] >= 0.33):
                                                remove_points += 1
                                            if (transitions_df.at[t,"zero_proportion"] < 0.45):
                                                remove_points += 1
                                            if (transitions_df.at[t,"mean"] >= 0.66*metric):
                                                remove_points += 0.5
                                            if (
                                                (transitions_df.at[t,"length"]/len(window) >= 0.3) or
                                                (
                                                  (t > 0) and 
                                                  (transitions_df.at[t,"length"] >= 1.5*transitions_df.at[t-1,"length"])
                                                )
                                               ):
                                                remove_points -= 1

                                            if remove_points > 1.5:
                                                remove = True

                                if remove:
                                    # Transition filtering process takes place

                                    start = int(transitions_df.at[t-1,"start"])

                                    if t < num_transitions_window-1:
                                        end = int(transitions_df.at[t+1,"end"])
                                        transitions_df.drop(index=[t,t+1],inplace=True)

                                    else:
                                        end = int(transitions_df.at[t,"end"])
                                        transitions_df.drop(index=[t],inplace=True)

                                    transitions_df.at[t-1,"end"] = end

                                    sliced = window[start:end]

                                    slice_len = end-start
                                    transitions_df.at[t-1,"length"] = slice_len

                                    slice_mean = np.mean(sliced)
                                    transitions_df.at[t-1,"mean"] = slice_mean

                                    slice_median = np.median(sliced)
                                    transitions_df.at[t-1,"median"] = slice_median

                                    slice_zeros = np.sum(np.where(sliced == 0,1,0))/(end-start)
                                    transitions_df.at[t-1,"zero_proportion"] = slice_zeros

                                    slice_abvm = np.sum(np.where(sliced > metric,1,0))/(end-start)
                                    transitions_df.at[t-1,"abvm_proportion"] = slice_abvm

                                    num_transitions_window = len(transitions_df)
                                    transitions_df.index = range(num_transitions_window)
                                    if verbose:
                                        print("intermediate transitions_df\n",transitions_df)

                                else:
                                    t += 1

                        if verbose:
                            print("filtered transitions_df\n",transitions_df)

                        new_bed_time = []
                        for t in range(len(transitions_df)):
                            start = int(start_m + transitions_df.at[t,"start"])
                            end = int(start_m + transitions_df.at[t,"end"])
                            edge_levels[start:end] = transitions_df.at[t,"mean"]

                            if (transitions_df.at[t,"class"] == "v"):
                                if t > 0:
                                    if (transitions_df.at[t,"mean"] < 0.5*transitions_df.at[t-1,"mean"]):
                                        new_bed_time.append(int(transitions_df.at[t,"start"]))
                                else:
                                    new_bed_time.append(int(transitions_df.at[t,"start"]))

                        # First steps to determine the point where xf_aux crosses the calculated metric threshold
                        xf_metric_cross = np.where(xf_aux[start_m:end_m+1] >= metric, 1, 0)
                        xf_metric_cross = np.diff(np.concatenate(([0],xf_metric_cross)))
                        xf_metric_cross_up = (xf_metric_cross > 0).nonzero()[0]
                        xf_metric_cross_down = (xf_metric_cross < 0).nonzero()[0]

                        n_bt = len(new_bed_time)
                        if (n_bt == 0):
                            new_bed_time = transitions_df[transitions_df["class"] == "v"].loc[:,"start"].to_numpy().astype(int)
                        
                        new_bed_time = np.array(new_bed_time)

                        if verbose:
                            print("new_bed_time\n",new_bed_time)

                        if len(xf_metric_cross_up) > 0:
                            # If there are multiple metric crossings, all candidates preceding the last crossing are eliminated
                            xf_metric_cross_up = xf_metric_cross_up[len(xf_metric_cross_up)-1]
                            mask = np.where(new_bed_time >= xf_metric_cross_up,True,False)
                            new_bed_time = new_bed_time[mask]
                            if verbose:
                                print("mask new_bed_time\n",new_bed_time)

                        n_bt = len(new_bed_time)
                        if n_bt > 0:
                            nbt_points = np.array([[0.0,nbt] for nbt in new_bed_time])
                            nbt_points[n_bt-1,0] += bt_last

                            if len(xf_metric_cross_down) > 0:
                                xf_metric_cross_down = xf_metric_cross_down[len(xf_metric_cross_down)-1]
                                xf_mc_distance = np.absolute(new_bed_time - xf_metric_cross_down)
                                best_distance_index = np.argmin(xf_mc_distance)
                                nbt_points[best_distance_index,0] += bt_cross

                                if verbose:
                                    print("xf_metric_cross_down",xf_metric_cross_down)
                                    print("best_distance_index",best_distance_index)

                            # Candidates are stored with their median difference value
                            new_bed_time_w = [[get_peak(smooth_median_diff,new_bed_time[k],True),new_bed_time[k],self.time_index[start_m+new_bed_time[k]],k] for k in range(n_bt)]

                            if verbose:
                                print("new_bed_time_w\n",new_bed_time_w)

                            n_bt_w = len(new_bed_time_w)

                            if n_bt_w > 0:   # This condition makes sure that the median difference was calculated in at least one of the indexes
                                new_bed_time_w = sorted(new_bed_time_w, key=get_key0) # Candidates are sorted by median difference                            

                                nbt_points[new_bed_time_w[0][3],0] += bt_diff

                                if verbose:
                                    print("sorted new_bed_time_w\n",new_bed_time_w)
                                    print("n_bt_w",n_bt_w)

                                if condition in [0,2]:
                                    choice = 0
                                    aux = []
                                    thresholded_candidates = []
                                    while (choice < n_bt_w):
                                        candidate = start_m+new_bed_time_w[choice][1]

                                        search_end = candidate+candidate_search_time
                                        if search_end > n:
                                            search_end = n
                                        next_time = self.activity[candidate:search_end]

                                        no_gap = True
                                        g = candidate
                                        while no_gap and (g+1 < search_end):
                                            if pd.Timedelta(self.time_index[g+1]-self.time_index[g])/np.timedelta64(1,'s') > gap_thresh:
                                                if verbose:
                                                    print("gap",pd.Timedelta(self.time_index[g+1]-self.time_index[g])/np.timedelta64(1,'s'))
                                                no_gap = False
                                            g += 1
                                        
                                        if no_gap:
                                            thresholded = np.where(next_time >= metric,1,0)   # And evaluate how many epochs inside the window are above the metric

                                            aux.append([np.sum(thresholded),choice,new_bed_time_w[choice][3]])
                                            if np.sum(thresholded) <= candidate_max_over_thershold_bt:
                                                thresholded_candidates.append([np.sum(thresholded),choice,new_bed_time_w[choice][3]])

                                        choice += 1

                                    aux = np.array(aux)
                                    thresholded_candidates = np.array(thresholded_candidates,dtype=float)
                                    if verbose:
                                        print("aux",aux)
                                        print("thresholded_candidates\n",thresholded_candidates)

                                    if len(aux) > 0:
                                        if len(thresholded_candidates) == 0:   # If there aren't any valid candidates, the one with the least above-metric epochs is chosen
                                            best_choice = sorted(aux, key=get_key0)[0][1]
                                            # new_bed_time_w = start_m+new_bed_time_w[best_choice][1]
                                            nbt_points[new_bed_time_w[best_choice][3],0] += bt_aux

                                        else:
                                            # The valid candidate with the smallest median difference is chosen
                                            # new_bed_time_w = start_m+new_bed_time_w[thresholded_candidates[0][1]][1]
                                            sums = thresholded_candidates[:,0].copy()
                                            # thresholded_candidates[:,0] = (-1.0/np.std(sums))*(sums-np.mean(sums))
                                            thresholded_candidates[:,0] = (-bt_threshamp/candidate_max_over_thershold_bt)*(np.array(sums,dtype=float)-candidate_max_over_thershold_bt)
                                            if verbose:
                                                print("scored thresholded_candidates\n",thresholded_candidates)
                                            # best_choice = sorted(thresholded_candidates, key=get_key0)[0][1]
                                            for tc in range(len(thresholded_candidates)):
                                                nbt_points[new_bed_time_w[int(thresholded_candidates[tc][1])][3],0] += thresholded_candidates[tc][0]+bt_threshmin

                                    # else:
                                    #     new_bed_time_w = index   # If there aren't candidates at all, we'll stick with the initial guess
                                    if verbose:
                                        print("nbt_points\n",nbt_points)
                                    nbt_points = np.array(sorted(nbt_points, key=get_key0, reverse=True))
                                    if verbose:
                                        print("sorted nbt_points\n",nbt_points)
                                    top_grader = nbt_points[0,1]
                                    top_grade = nbt_points[0,0]

                                    nbti = 1
                                    while ((nbti < n_bt) and (nbt_points[nbti,0] == top_grade)):
                                        if nbt_points[nbti,1] > top_grader:
                                            top_grader = nbt_points[nbti,1]
                                        nbti += 1

                                    new_bed_time_w = start_m + int(top_grader)

                                    if verbose:
                                        print("top_grader",top_grader)
                                        print(new_bed_time_w)

                            else:
                                new_bed_time_w = start_m + new_bed_time[-1]

                            final = new_bed_time_w

                            new_bed_time = final
                            if verbose:
                                print("final",final)
                                print("new_bed_time",new_bed_time)

                        else:
                            new_bed_time = index    # Mantains if no edges are detected

                        nb = np.append(nb,new_bed_time)
                        refined_transitions[i][0] = new_bed_time
                        if end_m > start_m:
                            edge_median[start_m:end_m+1] = median
                            edge_median_diff[start_m+1:end_m+1] = smooth_median_diff
                            edge_metric[start_m:end_m+1] = metric
                            # edge_fourier[start_m:end_m] = filtered

                        refined_output[previous_transition:new_bed_time] = 1

                    else:   # Getup time refinement 
                        end_m = index + 1

                        no_gap = True
                        td = pd.Timedelta(self.time_index[end_m]-self.time_index[end_m-1])/np.timedelta64(1,'s') 
                        if td > gap_thresh:
                            
                            no_gap = False

                        if end_m >= xf_min:
                            hi_xf = xf_aux[end_m-xf_min:end_m] 
                        else:
                            hi_xf = xf_aux[0:end_m] 

                        hi_xf = np.where(hi_xf > quantile_threshold,1,0)
                        sum_min = len(hi_xf)

                        while (   # Boundary conditions for the beggining of the getup time refinement interval
                                   (end_m+1 < n) and 
                                   (end_m+1 < next_transition) and
                                   no_gap and
                                   (np.sum(hi_xf) < sum_min)
                              ):
                            end_m += 1   # Interval is stretched to the right
                            # print("gt end_m",end_m)

                            td = pd.Timedelta(self.time_index[end_m]-self.time_index[end_m-1])/np.timedelta64(1,'s') 
                            if td > gap_thresh:
                                
                                no_gap = False

                            if end_m >= xf_min:
                                hi_xf = xf_aux[end_m-xf_min:end_m] 
                            else:
                                hi_xf = xf_aux[0:end_m] 

                            hi_xf = np.where(hi_xf > quantile_threshold,1,0)
                            sum_min = len(hi_xf)
                        
                        start_m = index-ending_search-1
                        if start_m < 0:
                            start_m = 0
                            
                        no_gap = True
                        if start_m > 0:
                            td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')
                            if td > gap_thresh:
                                
                                no_gap = False

                        # print(start_m,end_m)
                        if start_m-mws >= 0:
                            if end_m+mws+1 <= n:
                                median_vec = self.activity[start_m-mws:end_m+mws+1]
                            else:
                                median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                        else:
                            median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                        median = median_filter(median_vec,mws,padding='padded')
                        mean = 0
                        metric = 0
                        median_over_zero = median[np.where(median > 0)]
                        if len(median_over_zero) > 0:
                            mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                            if metric_choice == 1:
                                fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                metric = fraction_mean
                            elif metric_choice == 2:
                                p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                metric = p
                
                        median_ending = median[0:median_search]

                        if ((start_m+ending_search) < n):
                            ending_end = start_m+ending_search+1
                        else:
                            ending_end = n

                        if ((start_m-ending_search) > 0):
                            ending_start = start_m-ending_search
                        else:
                            ending_start = 0
                        
                        ending = self.activity[ending_start:ending_end]
                        zero_proportion = np.sum(np.where(ending == 0,1,0))/(ending_end-ending_start)

                        while (   # Boundary conditions for the end of the getup time refinement interval
                                   (start_m > 0) and 
                                   (start_m-1 > previous_transition) and 
                                   no_gap and
                                   (
                                       (zero_proportion < zero_proportion_threshold) or
                                       (np.sum(np.where(median_ending >= metric,1,0)) > 0)
                                   )
                              ):
                            start_m -= 1    # Interval is stretched to the left
                            # print("gt start_m",start_m)

                            if start_m > 0:
                                td = pd.Timedelta(self.time_index[start_m]-self.time_index[start_m-1])/np.timedelta64(1,'s')
                                if td > gap_thresh:
                                    
                                    no_gap = False

                            if start_m-mws >= 0:
                                if end_m+mws+1 <= n:
                                    median_vec = self.activity[start_m-mws:end_m+mws+1]
                                else:
                                    median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                            else:
                                median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                            median = median_filter(median_vec,mws,padding='padded')
                            mean = 0
                            metric = 0
                            median_over_zero = median[np.where(median > 0)]
                            if len(median_over_zero) > 0:
                                mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                                if metric_choice == 1:
                                    fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                    metric = fraction_mean
                                elif metric_choice == 2:
                                    p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                    metric = p

                            median_ending = median[0:median_search]

                            if ((start_m+ending_search) < n):
                                ending_end = start_m+ending_search+1
                            else:
                                ending_end = n

                            if ((start_m-ending_search) > 0):
                                ending_start = start_m-ending_search
                            else:
                                ending_start = 0
                            
                            ending = self.activity[ending_start:ending_end]
                            zero_proportion = np.sum(np.where(ending == 0,1,0))/(ending_end-ending_start)

                        dt_diff = datetime_diff(time_index[start_m:end_m+1])
                        if np.max(dt_diff) >= gap_thresh:
                            end_m = end_m + np.argmax(dt_diff)

                        if start_m-mws >= 0:
                            if end_m+mws+1 <= n:
                                median_vec = self.activity[start_m-mws:end_m+mws+1]
                            else:
                                median_vec = np.concatenate((self.activity[start_m-mws:n],np.max(self.activity[start_m:end_m+1])*np.ones(end_m+mws+1-n)))
                        else:
                            median_vec = np.concatenate((np.max(self.activity[start_m:end_m+1])*np.ones(mws-start_m),self.activity[0:end_m+mws+1]))
                        median = median_filter(median_vec,mws,padding='padded')
                        mean = 0
                        metric = 0
                        median_over_zero = median[np.where(median > 0)]
                        if len(median_over_zero) > 0:
                            mean = np.mean(median_over_zero)    # Mean of non-zero elements in filtered array            
                            if metric_choice == 1:
                                fraction_mean = fraction*mean   # User-set fraction of the mean metric
                                metric = fraction_mean
                            elif metric_choice == 2:
                                p = np.quantile(median_over_zero, fraction, interpolation='linear')   # Quantile metric
                                metric = p

                        median_diff = np.diff(median)
                        smooth_median_diff = median_filter(median_diff,mws,padding='same')

                        xf_metric_cross = np.where(xf_aux[start_m:end_m+1] >= metric, 1, 0)
                        xf_metric_cross = np.diff(np.concatenate(([0],xf_metric_cross)))
                        xf_metric_cross = (xf_metric_cross > 0).nonzero()[0]

                        window = self.activity[start_m:end_m+1]
                        transitions_df = make_transitions_df(window,median,metric,False)

                        if verbose:
                            print("\ngetup time refinement")
                            print("metric",metric) 
                            print("transitions_df\n",transitions_df)

                        num_transitions_window = len(transitions_df)
                        transitions_df.index = range(num_transitions_window-1,-1,-1)    # Transistions will be reindex such that the last (closer to wake period) is regarded as the first ()
                        if ((num_transitions_window > 2) and (num_transitions_window != 3)):
                            if (transitions_df.at[0,"class"] == "v"):
                                if (transitions_df.at[0,"length"] < gt_v_length_thresh):
                                    start = int(transitions_df.at[1,"start"])
                                    end = int(transitions_df.at[0,"end"])

                                    transitions_df.at[0,"start"] = start

                                    sliced = window[start:end]

                                    slice_len = end-start
                                    transitions_df.at[0,"length"] = slice_len

                                    slice_mean = np.mean(sliced)
                                    transitions_df.at[0,"mean"] = slice_mean

                                    slice_median = np.median(sliced)
                                    transitions_df.at[0,"median"] = slice_median

                                    slice_zeros = np.sum(np.where(sliced == 0,1,0))/(end-start)
                                    transitions_df.at[0,"zero_proportion"] = slice_zeros

                                    slice_abvm = np.sum(np.where(sliced > metric,1,0))/(end-start)
                                    transitions_df.at[0,"abvm_proportion"] = slice_abvm

                                    transitions_df.at[0,"class"] = "p"

                                    transitions_df.drop(index=[1],inplace=True)
                                    num_transitions_window = len(transitions_df)
                                    transitions_df.index = range(num_transitions_window-1,-1,-1)

                            t = 1
                            while (t < num_transitions_window) and ((num_transitions_window > 2) and (num_transitions_window != 3)):
                                # print("gt t",t)
                                remove = False
                                # Remove conditions here are very similar to their bedtime counterparts

                                if (transitions_df.at[t,"class"] == "p"):
                                    if (transitions_df.at[t,"length"] < gt_p_length_thresh):
                                        remove = True

                                    elif (transitions_df.at[t,"length"] < 2*gt_p_length_thresh):
                                        if (
                                            (
                                             (transitions_df.at[t-1,"length"] >= 3*transitions_df.at[t,"length"]) and 
                                             (transitions_df.at[t-1,"zero_proportion"] > 0.5)
                                            ) 
                                            or (transitions_df.at[t-1,"length"] >= 10*transitions_df.at[t,"length"])
                                           ):
                                            remove = True

                                else:#(transitions_df.at[t,"class"] == "v")
                                    if (t < num_transitions_window-1):
                                        if (transitions_df.at[t,"length"] < gt_v_length_thresh):
                                            remove = True

                                        else:
                                            remove_points = 0
                                            if (transitions_df.at[t,"abvm_proportion"] > 0.25):
                                                remove_points += 1
                                            if (transitions_df.at[t,"zero_proportion"] < 0.45):
                                                remove_points += 1
                                            if (transitions_df.at[t,"mean"] >= 0.66*metric):
                                                remove_points += 0.5
                                            if (
                                                (transitions_df.at[t,"length"]/len(window) >= 0.3) or
                                                (
                                                  (t > 0) and 
                                                  (transitions_df.at[t,"length"] >= 1.5*transitions_df.at[t-1,"length"])
                                                )
                                               ):
                                                remove_points -= 1

                                            if remove_points > 1.5:
                                                remove = True

                                if remove:
                                    # Transition filtering process here is also just slightly different

                                    end = int(transitions_df.at[t-1,"end"])

                                    if t < num_transitions_window-1:
                                        start = int(transitions_df.at[t+1,"start"])
                                        transitions_df.drop(index=[t,t+1],inplace=True)

                                    else:
                                        start = int(transitions_df.at[t,"start"])
                                        transitions_df.drop(index=[t],inplace=True)

                                    transitions_df.at[t-1,"start"] = start

                                    sliced = window[start:end]

                                    slice_len = end-start
                                    transitions_df.at[t-1,"length"] = slice_len

                                    slice_mean = np.mean(sliced)
                                    transitions_df.at[t-1,"mean"] = slice_mean

                                    slice_median = np.median(sliced)
                                    transitions_df.at[t-1,"median"] = slice_median

                                    slice_zeros = np.sum(np.where(sliced == 0,1,0))/(end-start)
                                    transitions_df.at[t-1,"zero_proportion"] = slice_zeros

                                    slice_abvm = np.sum(np.where(sliced > metric,1,0))/(end-start)
                                    transitions_df.at[t-1,"abvm_proportion"] = slice_abvm

                                    num_transitions_window = len(transitions_df)
                                    transitions_df.index = range(num_transitions_window-1,-1,-1)
                                    if verbose:
                                        print("t",t,"transitions_df\n",transitions_df)

                                else:
                                    t += 1

                        transitions_df.index = range(num_transitions_window)
                        if verbose:
                            print("filtered transitions_df\n",transitions_df)


                        new_getup_time = []
                        getup_time_end = []
                        for t in range(num_transitions_window):
                            start = int(start_m + transitions_df.at[t,"start"])
                            end = int(start_m + transitions_df.at[t,"end"])
                            edge_levels[start:end] = transitions_df.at[t,"mean"]

                            if (transitions_df.at[t,"class"] == "p"):
                                if t > 0:
                                    if (transitions_df.at[t,"mean"] > 2*transitions_df.at[t-1,"mean"]):
                                        new = int(transitions_df.at[t,"start"])
                                        new_getup_time.append(new)

                        if (transitions_df.at[num_transitions_window-1,"class"] == "v"):
                            new = int(transitions_df.at[num_transitions_window-1,"end"])
                            if start_m+new == n:
                                new -=1
                            new_getup_time.append(new)
                                    
                        if verbose:
                            print("new_getup_time",new_getup_time)

                        n_gt = len(new_getup_time)
                        if n_gt > 0:
                            ngt_points = np.array([[0.0,ngt] for ngt in new_getup_time])
                            ngt_points[0,0] += gt_first
                            new_getup_time_w = [[get_peak(smooth_median_diff,new_getup_time[k]),new_getup_time[k],k,self.time_index[start_m+new_getup_time[k]]] for k in range(n_gt)]
                            new_getup_time_w = sorted(new_getup_time_w, key=get_key0)
                            if verbose:
                                print("new_getup_time_w",new_getup_time_w)

                            ngt_points[new_getup_time_w[n_gt-1][2],0] += gt_diff
                            
                            if len(xf_metric_cross) > 0:   # The metric threshold crossing point here is used as a decision parameter
                                # The candidate that's nearest to the crossing is likely to be the chosen one

                                xf_metric_cross = xf_metric_cross[0]
                                
                                xf_mc_distance = np.absolute(new_getup_time - xf_metric_cross)
                                best_distance_index = np.argmin(xf_mc_distance)
                                if verbose:
                                    print("xf_metric_cross",xf_metric_cross)
                                    print("best_distance_index",best_distance_index)

                                ngt_points[best_distance_index,0] += gt_cross

                            choice = 0
                            aux = []
                            thresholded_candidates = []
                            while (choice < n_gt):
                                candidate = start_m+new_getup_time[choice]

                                search_end = candidate+candidate_search_time
                                if search_end > n:
                                    search_end = n
                                next_time = self.activity[candidate:search_end]   # We'll look at a window after the candidate epoch

                                no_gap = True
                                g = candidate
                                while no_gap and (g+1 < search_end):
                                    if pd.Timedelta(self.time_index[g+1]-self.time_index[g])/np.timedelta64(1,'s') > gap_thresh:
                                        if verbose:
                                            print("gap",pd.Timedelta(self.time_index[g+1]-self.time_index[g])/np.timedelta64(1,'s'))
                                        no_gap = False
                                    g += 1

                                
                                if no_gap:
                                    thresholded = np.where(next_time <= metric,1,0)   # And evaluate how many epochs inside the window are above the metric

                                    aux.append([np.sum(thresholded),choice,new_getup_time_w[choice][2]])
                                    if np.sum(thresholded) <= candidate_max_over_thershold_gt:
                                        thresholded_candidates.append([np.sum(thresholded),choice,new_getup_time_w[choice][2]])

                                choice += 1

                            aux = np.array(aux)
                            thresholded_candidates = np.array(thresholded_candidates,dtype=float)
                            if verbose:
                                print("aux",aux)
                                print("thresholded_candidates\n",thresholded_candidates)

                            if len(aux) > 0:
                                if len(thresholded_candidates) == 0:   # If there aren't any valid candidates, the one with the least above-metric epochs is chosen
                                    best_choice = sorted(aux, key=get_key0)[0][1]
                                    # new_bed_time_w = start_m+new_bed_time_w[best_choice][1]
                                    ngt_points[new_getup_time_w[best_choice][2],0] += gt_aux

                                else:
                                    sums = thresholded_candidates[:,0].copy()
                                    thresholded_candidates[:,0] = (-gt_threshamp/candidate_max_over_thershold_gt)*(np.array(sums,dtype=float)-candidate_max_over_thershold_gt)
                                    if verbose:
                                        print("scored thresholded_candidates\n",thresholded_candidates)
                                    for tc in range(len(thresholded_candidates)):
                                        ngt_points[new_getup_time_w[int(thresholded_candidates[tc][1])][2],0] += thresholded_candidates[tc][0]+gt_threshmin

                            if verbose:
                                print("ngt_points",ngt_points)
                            ngt_points = np.array(sorted(ngt_points, key=get_key0, reverse=True))
                            if verbose:
                                print("sorted ngt_points",ngt_points)

                            top_grader = ngt_points[0,1]
                            top_grade = ngt_points[0,0]

                            ngti = 1
                            while ((ngti < n_gt) and (ngt_points[ngti,0] == top_grade)):
                                if ngt_points[ngti,1] < top_grader:
                                    top_grader = ngt_points[ngti,1]
                                ngti += 1                    

                            new_getup_time = start_m + int(top_grader)
                            if verbose:
                                print("top_grader",top_grader)

                        else:
                            new_getup_time = index

                        ng = np.append(ng,new_getup_time)
                        refined_transitions[i][0] = new_getup_time

                        if end_m > start_m:
                            edge_median[start_m:end_m+1] = median
                            edge_median_diff[(start_m+1):end_m+1] = smooth_median_diff
                            edge_metric[start_m:end_m+1] = metric
                            # edge_fourier[start_m:end_m] = filtered

                    i += 1

                if refined_transitions[-1][1] > 0:
                    refined_output[refined_transitions[-1][0]:n] = 1

            else:
                refined_output = np.ones(n)

    
            nap_min = int(round(nap_min*60/self.interval))
            
            if nap:
                output = seq_len_filt(nap_min,refined_output)
                refined_output = output.copy()
                edges = np.diff(output)
                edges_index = edges.nonzero()[0]
                refined_transitions = [[i,edges[i]] for i in edges_index]

            self.refined_transitions = np.array([[self.time_index[rt[0]],*rt] for rt in refined_transitions])

            # Heuristic rule
            output[0] = 1
            output[-1] = 1
            refined_output[0] = 1
            refined_output[-1] = 1

            self.sleep_quantil = np.quantile(xfa, self.sleep_quantil, interpolation='linear')

        else:
            xf = None
            xf_aux = None
            y1 = None
            ye = None
            xfa = None
            y2 = None
            quantile_threshold = None
            edge_median = None
            edge_levels = None
            edge_metric = None
            edge_fourier = None
            edge_median_diff = None
            refined_bed_times = None
            refined_getup_times = None
            self.sleep_quantil = None
            
            output = np.ones(n)
            refined_output = np.ones(n)

        if not nap:
            self.xf = xf
            self.y1 = y1
            self.ye = ye
            self.xfa = xfa

        self.y2 = y2
        self.xf_aux = xf_aux
        self.quantile_threshold = quantile_threshold
        self.edge_median = edge_median
        self.edge_levels = edge_levels
        self.edge_metric = edge_metric
        self.edge_fourier = edge_fourier
        self.edge_median_diff = edge_median_diff
        
        self.refined_bed_times = nb
        self.refined_getup_times = ng

        self.output = output
        self.refined_output = refined_output