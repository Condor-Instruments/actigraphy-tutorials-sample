import sys
import inspect
import os
import cProfile, pstats, io
import time as ttime

import pandas as pd
import xgboost as xgb
import numpy as np

from scipy.ndimage import binary_closing, binary_opening

from functions import *

from logreg import LogReg


def boosting_offwrist_feature(df,half_window_length,varbs,tvarbs,dvarbs):
	df = df[df["TEMPERATURE"] > 0]

	n = len(df)

	lg = LogReg(df["PIM"].to_numpy(),half_window_length=half_window_length,variables=varbs,verbose=False)
	data = lg.data

	int_temp = df["TEMPERATURE"].to_numpy()
	ext_temp = df["EXT TEMPERATURE"].to_numpy()
	dif_temp = np.absolute(np.subtract(int_temp,ext_temp))

	lg = LogReg(int_temp,half_window_length=half_window_length,column_prefix='temp_',variables=tvarbs,verbose=False)
	data = pd.concat([data,lg.data],axis=1,ignore_index=False)

	start_time = ttime.time()
	lg = LogReg(dif_temp,half_window_length=half_window_length,column_prefix='dif_',variables=dvarbs,verbose=False)
	# print("lg3 ",ttime.time()-start_time,"\n")

	# print(data)
	# print(lg.data)

	data = pd.concat([data,lg.data],axis=1,ignore_index=False)

	# print(data)

	diff = np.diff(np.concatenate(([0],int_temp)))
	me_diff = mean_filter(diff,2)

	data["diff_temp"] = np.abs(me_diff)
	data["ext_temp"] = ext_temp

	return data