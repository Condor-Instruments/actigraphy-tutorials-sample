import pandas as pd
import numpy as np
from datetime import date,datetime,timedelta,time

def actigraphy_calculate_SRI(df,sleep,visualize=False):
    regular_epochs = 0
    num_epochs = 0
    sri = 0
    last = df.index.to_series().iat[-1]

    if visualize:
        visual = pd.DataFrame([],columns=["di","si","si_","di_","delta"])

    for m in df.index:
        si = df.at[m,sleep]
        if si != 4:  # melhor maneira? tambem pode ser só drop
            next_day = m+pd.Timedelta(days=1)
            if next_day <= last: 
                if next_day in df.index:  # pode haver pequeno gap
                    si_ = df.at[next_day,sleep]
                    if si_ != 4:
                        delta = 0
                        if si_ == si:
                            regular_epochs += 1
                            delta = 1

                        num_epochs += 1

                        if visualize:
                            v = pd.DataFrame([[m,si,next_day,si_,delta]],columns=["di","si","si_","di_","delta"])
                            visual = pd.concat([visual,v],ignore_index=True)
            else:
                break

    if num_epochs > 0:
        sri = -100 + 200*(regular_epochs/num_epochs)
        print("calc",num_epochs)

        if visualize:
            visual.to_csv("visualize.csv",header=True,index=False)

    return sri

# index = pd.date_range(start='2/28/2022',end='3/15/2022',freq="T",inclusive="left")
# N = 15
# M = 24*60

# print(index)
# print("N",N)
# print('M',M)
# print("exp",M*(N-1))

# df = pd.DataFrame([],columns=["datetime","sleep"],index=index)
# df["sleep"] = np.zeros(len(df))
# df["datetime"] = df.index.strftime('%d/%m/%Y %H:%M:%S')

# for m in df.index:
#   if (m.hour >= 20) or (m.hour <= 4):
#     df.at[m,"sleep"] = 1

# print("sri",actigraphy_calculate_SRI(df,"sleep"))

# day = 28
# bedtime = np.random.randint(18,24)
# getuptime = np.random.randint(7)

# df["sleep"] = np.zeros(len(df))
# for m in df.index:
#   if m.day != day:
#     bedtime = np.random.randint(18,24)
#     getuptime = np.random.randint(7)
#     day = m.day

#   if (m.hour >= bedtime) or (m.hour <= getuptime):
#     df.at[m,"sleep"] = 1

# print("sri",actigraphy_calculate_SRI(df,"sleep",True))