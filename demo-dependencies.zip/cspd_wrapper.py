import numpy as np
from cspd import CSPD as cd

def cspd_wrapper(df,verbose=False):
    onwrist = np.where(df["state"].to_numpy() == 4, False, True)

    cspd = cd(df["activity"].to_numpy()[onwrist],
               df["datetime"].to_numpy()[onwrist])
    cspd.model(verbose=verbose)

    state = np.where(onwrist,0,4)
    state[onwrist] = 1-cspd.refined_output

    return state