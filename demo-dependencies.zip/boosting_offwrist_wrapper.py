import sys
import inspect
import os
import cProfile, pstats, io
import time as ttime

import pandas as pd
import xgboost as xgb
import numpy as np

from functions import *
from boosting_offwrist_refine import boosting_offwrist_refine
from boosting_offwrist_feature import boosting_offwrist_feature

new = True

n_estimators = 600
max_depth = 10

xg_reg = xgb.XGBClassifier(objective='binary:logistic',
                                   max_delta_step=1,
                                   min_child_weight=10,
                                   # colsample_bytree=0.3,
                                   # scale_pos_weight=12,
                                   grow_policy="lossguide",
                                   learning_rate=0.05,
                                   max_depth=max_depth, 
                                   alpha=10, 
                                   n_estimators=n_estimators,
                                   eval_metric="auc",
                                   )

model_name = "model_n="+str(n_estimators)+"_d="+str(max_depth)+"_new_multconfig.json"
xg_reg.load_model(model_name)

mwl = 15
nw = 10
half_window_length = np.linspace(1,mwl,nw,dtype=int)

varbs = ["act","std","zp","median"]
tvarbs = ["act","std","median"]
dvarbs = ["act","std","zp","median"]

params = {"half_window_length": half_window_length,"variables":varbs,}
tparams = {"half_window_length": half_window_length,"column_prefix":'temp_',"variables":tvarbs,}
dparams = {"half_window_length": half_window_length,"column_prefix":'dif_',"variables":dvarbs,}

morph = 8
thresh_fraction = 0.3
bp_thresh = 0.7
filt_wl = 180
begin_below_thresh = 0.6
end_below_thresh = 0.6
begin_on_thresh = 0.8
end_on_thresh = 0.8
length_thresh = 60
cutoff = 0.51

def boosting_offwrist_wrapper(df):
    pr = cProfile.Profile()
    pr.enable()

    data = boosting_offwrist_feature(df,half_window_length,varbs,tvarbs,dvarbs)

    prob = xg_reg.predict_proba(data)[:,0]

    out = np.where(prob >= cutoff,1,0)

    act = data["activity"].to_numpy()
    dif_temp = data["dif_activity"].to_numpy()

    out_filt = 4*(1-boosting_offwrist_refine(out,act,dif_temp,morph=morph,thresh_fraction=thresh_fraction,bp_thresh=bp_thresh,filt_wl=filt_wl,begin_below_thresh=begin_below_thresh,end_below_thresh=end_below_thresh,begin_on_thresh=begin_on_thresh,end_on_thresh=begin_on_thresh,length_thresh=begin_on_thresh,))

    # print("total ",ttime.time()-start_time_,"\n")

    pr.disable()
    # s = io.StringIO()
    # ps = pstats.Stats(pr,stream=s).sort_stats("cumulative")
    # ps.print_stats()
    # print(s.getvalue())

    return out_filt