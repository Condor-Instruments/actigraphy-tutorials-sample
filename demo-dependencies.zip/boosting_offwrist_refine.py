import numpy as np
from scipy.ndimage import binary_closing, binary_opening

from functions import *

def offwrist_refine(out,act,dif,morph=8,thresh_fraction=0.3,bp_thresh=0.7,filt_wl=180,begin_below_thresh=0.6,end_below_thresh=0.6,begin_on_thresh=0.8,end_on_thresh=0.8,length_thresh=60,verbose=False,time_index=[]):
    strel = np.ones(morph)   # Morphological strutcturing element
    out_morph = binary_opening(binary_closing(out,strel),strel).astype(int)

    time_idx = len(time_index) > 0

    n = len(out_morph)

    edges = np.concatenate(([0],np.diff(out_morph)))
    edges_index = edges.nonzero()[0]
    transitions = [[k,edges[k]] for k in edges_index]

    if len(transitions) > 0:
        if transitions[0][1] > 0:
            transitions.insert(0,[0,-1])

        if transitions[-1][1] < 0:
            transitions.append([n-1,1])

    offs = [[],[]]
    for transition in transitions:
        if transition[1] < 0:
            offs[0].append(transition[0])

        elif transition[1] > 0:
            offs[1].append(transition[0])

    offs = np.transpose(offs)
    num_offs = len(offs)

    if verbose:
        # print(file)
        if time_idx:
            time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
            for toff in time_offs:
                print(toff)
        else:
            print(offs)

    fullzp = zero_prop(act)
    thresh = np.percentile(act,round(100*(fullzp+(1-fullzp)*thresh_fraction)))
    dif_thresh = np.percentile(dif,round(100*(fullzp+(1-fullzp)*0.5*thresh_fraction)))

    if verbose:
        print("numbers")
        print(fullzp)
        print(thresh)

    remove = []
    for j in range(num_offs):
        begin = offs[j,0]
        end = offs[j,1]
        bp = below_prop(act[begin:end],thresh) 
        if verbose:
            if time_idx:
                print(j,time_offs[j],bp)
            else:
                print(j,offs[j],bp)

        if bp < bp_thresh:
            remove.append(j)
    offs = np.delete(offs,remove,axis=0)

    out_filt = np.ones(n)
    for off in offs:
        out_filt[off[0]:off[1]] = 0

    num_offs = len(offs)
    remove = []

    if verbose:
        if time_idx:
            time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
            for toff in time_offs:
                print(toff)
        else:
            print(offs)

    if num_offs > 0:
        for j in range(num_offs):
            if verbose:
                if time_idx:
                    print(j,time_offs[j])
                else:
                    print(j,offs[j])
                
            begin = offs[j,0]
            end = offs[j,1]

            length = end - begin

            if begin-filt_wl >= 0:
                begin_below_prop = below_prop(act[begin-filt_wl:begin],thresh)
                begin_on_prop = 1-zero_prop(out_filt[begin-filt_wl:begin])
            else:
                if begin >= 10:
                    begin_below_prop = below_prop(act[0:begin],thresh)
                    begin_on_prop = 1-zero_prop(out_filt[0:begin])                            
                else:
                    begin_below_prop = 0
                    begin_on_prop = 0

            if end+filt_wl <= n:
                end_below_prop = below_prop(act[end:end+filt_wl],thresh)
                end_on_prop = 1-zero_prop(out_filt[end:end+filt_wl])
            else:
                if end-n >= 10:
                    end_below_prop = below_prop(act[end:n],thresh)
                    end_on_prop = 1-zero_prop(out_filt[end:n])
                else:
                    end_below_prop = 0
                    end_on_prop = 0


            if verbose:
                print("length",length)
                print("begin_below_prop",begin_below_prop)
                print("end_below_prop",end_below_prop)
                print("begin_on_prop",begin_on_prop)
                print("end_on_prop",end_on_prop)

            if ((begin_below_prop > begin_below_thresh) or (end_below_prop > end_below_thresh)):
                if length <= length_thresh:
                    if ((begin_on_prop > begin_on_thresh) and (end_on_prop > end_on_thresh)):
                        remove.append(j)
                        if verbose:
                            print("removed")

        offs = np.delete(offs,remove,axis=0)
        if verbose:
            if time_idx:
                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
                for toff in time_offs:
                    print(toff)
            else:
                print(offs)
            print("")

        num_offs = len(offs)

        out_filt = np.zeros(n)
        if num_offs > 0:
            for off in offs:
                out_filt[off[0]:off[1]] = 1

            edges = np.concatenate(([0],np.diff(out_filt)))
            edges_index = edges.nonzero()[0]
            transitions = [[k,edges[k]] for k in edges_index]

            if len(transitions) > 0:
                if transitions[0][1] > 0:
                    transitions.insert(0,[0,-1])

                if transitions[-1][1] < 0:
                    transitions.append([n,1])

            ons = [[],[]]
            for transition in transitions:
                if transition[1] < 0:
                    ons[0].append(transition[0])

                elif transition[1] > 0:
                    ons[1].append(transition[0])

            ons = np.transpose(ons)

            # print(offs,"\n",ons)

            wl = 60
            num_ons = len(ons)
            remove = []
            for j in range(num_ons):
                begin = ons[j,0]
                end = ons[j,1]

                below_prop_ = below_prop(act[begin:end],thresh)
                dif_below_prop = below_prop(dif[begin:end],dif_thresh)

                length = end - begin

                if j == 0:
                    off_before_start = 0
                    if num_offs > 1:
                        off_after_end = ons[j+1,0]
                    else:
                        off_after_end = n

                elif j == num_ons-1:
                    off_before_start = ons[j-1,1]
                    off_after_end = n

                else:
                    off_before_start = ons[j-1,1]
                    off_after_end = ons[j+1,0]


                if begin-filt_wl >= 0:
                    begin_below_prop = below_prop(act[begin-filt_wl:begin],thresh)
                    begin_on_prop = 1-zero_prop(out_filt[begin-filt_wl:begin])
                else:
                    if begin >= 10:
                        begin_below_prop = below_prop(act[0:begin],thresh)
                        begin_on_prop = 1-zero_prop(out_filt[0:begin])                            
                    else:
                        begin_below_prop = 0
                        begin_on_prop = 0

                if end+filt_wl <= n:
                    end_below_prop = below_prop(act[end:end+filt_wl],thresh)
                    end_below_prop = 1-zero_prop(out_filt[end:end+filt_wl])
                else:
                    if end-n >= 10:
                        end_below_prop = below_prop(act[end:n],thresh)
                        end_on_prop = 1-zero_prop(out_filt[end:n])
                    else:
                        end_below_prop = 0
                        end_on_prop = 0

                
                len_before = begin - off_before_start
                len_after = off_after_end - end

                if length < 150:
                    if ((length <= len_before) and (length <= len_after)):
                        remove.append(j)

                    elif ((length <= len_before) or (length <= len_after)):
                        if ((begin_on_prop == 0.0) and (end_on_prop == 0.0)):
                            if below_prop_ > 0.666:
                                if dif_below_prop > 0.8:
                                    remove.append(j)

                # if length < 240:
                #     if (begin_on_prop == 0.0) and (end_on_prop == 0.0):
                #         remove.append(j)

                # else:
                #     if (off_after_end-off_before_start-length) > length 

            ons = np.delete(ons,remove,axis=0)

            # print(ons)

            out_filt = np.zeros(n)
            for on in ons:
                out_filt[on[0]:on[1]] = 1

    return out_filt