import sys
import inspect
import os
import cProfile, pstats, io
import time as ttime

import pandas as pd
import numpy as np

from functions import *


def offwrist_feature_bimodal(df,window_length,varbs,tvarbs,c1varbs,c2varbs,verbose=0):
        start_time_ = ttime.time()
        n = len(df)

        if varbs == None:
                data = pd.DataFrame([])

        else:
                pim = df["PIM"].to_numpy()
                start_time = ttime.time()    
                data = extract_features(pim,half_window_length=window_length,column_prefix="activity_",features=varbs)
                if verbose:
                        print("lg pim ",ttime.time()-start_time,"\n")

        if verbose > 1:
                print(data)

        if tvarbs != None:
                int_temp = df["TEMPERATURE"].to_numpy()
                start_time = ttime.time()
                int_temp_data = extract_features(int_temp,half_window_length=window_length,column_prefix='temperature_',features=tvarbs)
                data = pd.concat([data,int_temp_data],axis=1,ignore_index=False)
                if verbose:
                        print("lg temp ",ttime.time()-start_time,"\n")
                if verbose > 1:
                        print(int_temp_data)

        if verbose > 1:
                print(data)

        if c1varbs != None:
                if "CAP_SENS_1" in df.columns:
                        cap1 = norm_01(df["CAP_SENS_1"].to_numpy())
                        start_time = ttime.time()
                        cap1_data = extract_features(cap1,half_window_length=window_length,column_prefix='capsensor1_',features=c1varbs)
                        data = pd.concat([data,cap1_data],axis=1,ignore_index=False)
                        if verbose:
                                print("lg c1 ",ttime.time()-start_time,"\n")
                        if verbose > 1:
                                print(cap1_data)
                else:
                        if verbose:
                                print("no cap1 column\n")

        if verbose > 1:
                print(data)

        if c2varbs != None:
                if "CAP_SENS_2" in df.columns:
                        cap2 = norm_01(df["CAP_SENS_2"].to_numpy())
                        start_time = ttime.time()
                        cap2_data = extract_features(cap2,half_window_length=window_length,column_prefix='capsensor2_',features=c2varbs)
                        data = pd.concat([data,cap2_data],axis=1,ignore_index=False)
                        if verbose:
                                print("lg c2 ",ttime.time()-start_time,"\n")
                        if verbose > 1:
                                print(cap2_data)
                else:
                        if verbose:
                                print("no cap2 column\n")

        if verbose:
                print("total ",ttime.time()-start_time_,"\n")

        if verbose > 1:
                print(data)

        return data