import sys
import inspect
import os
import numpy as np
from scipy.ndimage import binary_closing, binary_opening
import matplotlib.pyplot as plt

from off_report import off_report

from functions import *


def offwrist_refine_bimodal(out,act,act_median,temp,temp_var,temp_thresh,ash_d,discriminant,hwl,lumus,extra,true=[],sleep=[],temp_var_q=0.9,length_thresh=60,ash_min=1.5,ash_max=2.6,qt_method="linear",min_on_length=20,min_off_length=15,verbose=False,time_index=[],sleep_filt_hws=210,sleep_conf="both",sleep_aqt=0.4,sleep_zqt=0.1,sleep_prop_max=0.4,cap_zp_thresh=0.25,temp_bp_thresh=0.6,bp_thresh=0.25,act_thresh_qt=0.3,dev=False,border="mod",min_act=500,act_bp_ft=0.75,just_bp=True,filt_on_bp=False,filt_on=True,act_filter=True,skip_len_bp=False,last_len_filt=True,ltv_filt=False,act_bp_filt=0.5,always_search_peak=False,quick_delete_start=True,bp_one_side=True,last_act_filt=True,report_filt=False,sleep_filter=False,dtm_filt=False,ltbfilt=False,short_slep_filt=True,cap_filt=False,act_border_filt=True):
    n = len(out)
    new_offs = []
    props = []
    act_thresh = 0 

    time_idx = len(time_index) > 0

    offs = zero_sequences(out)
    num_offs = len(offs)

    delta_over = 0
    delta_over_sleep = 0
    delta_okay = 0

    if num_offs > 0:
        temp_var_thresh = np.quantile(temp_var,temp_var_q,method=qt_method)
        if always_search_peak:
            temp_var_thresh_ = 1.0
        else:
            temp_var_thresh_ = temp_var_thresh

        low_temp_var_thresh = np.quantile(temp_var,0.4,method=qt_method)

        if verbose > 1:
            print("TEMP_VAR_THRESH",temp_var_thresh)
            print("initial offs\n",offs)
            if time_idx:
                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
                for toff in time_offs:
                    print(toff)

        zp_act = zero_prop(act)
        qt_act = zp_act + (1.0 - zp_act)*act_thresh_qt
        act_thresh = np.quantile(act,qt_act,method=qt_method)

        ons = zero_sequences(1-out)
        num_ons = len(ons)
        on_length = np.array([o[1]-o[0] for o in ons])
        on_act_bp = np.array([below_prop(act[o[0]:o[1]],act_thresh) for o in ons])
        on_act_zp = np.array([zero_prop(act[o[0]:o[1]]) for o in ons])

        if verbose > 1:
            # print("on_length",on_length)
            # print("on_act_bp",on_act_bp)
            # print("on_act_zp",on_act_zp)
            print("ons\n",ons)
            if time_idx:
                time_offs = [[time_index[ons[o][0]],time_index[ons[o][1]],on_length[o],on_act_bp[o],on_act_zp[o]] for o in range(num_ons)]
                for toff in time_offs:
                    print(toff)

        if filt_on:
            if filt_on_bp:
                ons = ons[np.where(np.logical_and(on_length > min_on_length, on_act_zp < 0.5),True,False)]
            else:
                ons = ons[np.where(on_length > min_on_length,True,False)]

        new_out = np.zeros(n)
        for on in ons:
            new_out[on[0]:on[1]] = 1.0

        offs = zero_sequences(new_out)
        num_offs = len(offs)
        if verbose > 1:
            print("mask ons\n",ons)
            print("on length filt offs\n",offs)
            if time_idx:
                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
                for toff in time_offs:
                    print(toff)

        if act_filter:
            act_bp = np.array([below_prop(act[o[0]:o[1]],act_thresh) for o in offs])
            if verbose > 1:
                print("act_bp offs",act_bp)
            offs = offs[np.where(act_bp > act_bp_filt,True,False)]
            num_offs = len(offs)
            if verbose > 1:
                print("act filt offs\n",offs)
                if time_idx:
                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in offs]
                    for toff in time_offs:
                        print(toff)

        act_bp = np.array([below_prop(act[o[0]:o[1]],act_thresh) for o in ons])
        if verbose > 1:
            print("act_bp ons",act_bp)

        hhwl = int(round(hwl/2))

        off = 0
        search_start = True
        while off < num_offs:
            if verbose > 1:
                print(off,offs[off])
            if search_start:
                start = offs[off][0]
                if len(new_offs) > 0:
                    previous_end = new_offs[-1][1]
                    if start < previous_end:
                        start = previous_end+2
                else:
                    previous_end = 0

                if verbose > 1:
                    print("start",start,temp_var[start])

                if start >= hwl:
                    if bp_one_side:
                        bpb = below_prop(temp_var[start-hwl:start+1],temp_var_thresh)
                    else:
                        bpb = below_prop(temp_var[start-hhwl:start+1+hhwl],temp_var_thresh)

                    if verbose > 1:
                        print("bpb",bpb)
                        if start >= 2*hwl:
                            print("bpb2",below_prop(temp_var[start-2*hwl:start+1],temp_var_thresh))
                        else:
                            print("bpb2",below_prop(temp_var[0:start+1],temp_var_thresh))

                    if temp_var[start] >= temp_var_thresh_:
                        if (bpb <= bp_thresh):
                            start = start - hwl + np.argmax(temp_var[start-hwl:start+1])
                            if start < previous_end:
                                start = previous_end+2

                            new_offs.append([start,0])
                            if verbose > 1:
                                print(new_offs)
                                if time_idx:
                                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                    for toff in time_offs:
                                        print(toff)
                            search_start = False
                        else:
                            if quick_delete_start:
                                offs = np.delete(offs,off,axis=0)
                                num_offs -= 1
                                if verbose > 1:
                                    print("delete")
                            else:
                                if verbose > 1:
                                    print("searching peak")

                                i = start-1
                                discriminant_ok = start
                                peak_base = start
                                while i > previous_end:
                                    border_bool = False

                                    if border == "disc":
                                        if discriminant[i]:
                                            border_bool = True
                                    elif border == "mod":
                                        if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)):
                                            border_bool = True
                                    elif border == "mod2":
                                        if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)) or (act_median[i] == 0):
                                            border_bool = True


                                    if border_bool:
                                        if temp_var[i] >= temp_var_thresh:
                                            peak_base = i
                                            i = previous_end
                                        i -= 1
                                    else:
                                        discriminant_ok = i
                                        i = previous_end

                                if discriminant_ok == start:
                                    if peak_base < start:
                                        if verbose > 1:
                                            print("peak found")
                                        peak = peak_base-1
                                        while temp_var[peak] >= temp_var[peak+1]:
                                            peak -= 1

                                        new_offs.append([peak,0])
                                        if verbose > 1:
                                            print(new_offs)
                                            if time_idx:
                                                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                                for toff in time_offs:
                                                    print(toff)
                                        search_start = False
                                    else:
                                        offs = np.delete(offs,off,axis=0)
                                        num_offs -= 1
                                        if verbose > 1:
                                            print("delete")

                                else:
                                    if verbose > 1:
                                        print("peak not found, no discriminant")

                                    new_offs.append([discriminant_ok,0]) 
                                    if verbose > 1:
                                        print(new_offs)
                                        if time_idx:
                                            time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                            for toff in time_offs:
                                                print(toff)
                                    search_start = False

                    else:
                        if verbose > 1:
                            print("searching peak")

                        if off > 0:
                            previous_end = offs[off-1][1]
                        else:
                            previous_end = 0

                        i = start-1
                        discriminant_ok = start
                        peak_base = start
                        while i > previous_end:
                            border_bool = False

                            if border == "disc":
                                if discriminant[i]:
                                    border_bool = True
                            elif border == "mod":
                                if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)):
                                    border_bool = True
                            elif border == "mod2":
                                if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)) or (act_median[i] == 0):
                                    border_bool = True


                            if border_bool:
                                if temp_var[i] >= temp_var_thresh:
                                    peak_base = i
                                    i = previous_end
                                i -= 1
                            else:
                                discriminant_ok = i
                                i = previous_end

                        if discriminant_ok == start:
                            if peak_base < start:
                                if verbose > 1:
                                    print("peak found")
                                peak = peak_base-1
                                while temp_var[peak] >= temp_var[peak+1]:
                                    peak -= 1

                                new_offs.append([peak,0])
                                if verbose > 1:
                                    print(new_offs)
                                    if time_idx:
                                        time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                        for toff in time_offs:
                                            print(toff)
                                search_start = False
                            else:
                                offs = np.delete(offs,off,axis=0)
                                num_offs -= 1
                                if verbose > 1:
                                    print("delete")

                        else:
                            if verbose > 1:
                                print("peak not found, no discriminant")

                            new_offs.append([discriminant_ok,0]) 
                            if verbose > 1:
                                print(new_offs)
                                if time_idx:
                                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                    for toff in time_offs:
                                        print(toff)
                            search_start = False
                else:
                    if verbose > 1:
                        print("bpb",below_prop(temp_var[0:start+1],temp_var_thresh))

                    start = np.argmax(temp_var[0:start+1])
                    new_offs.append([start,0])
                    if verbose > 1:
                        print(new_offs)
                        if time_idx:
                            time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                            for toff in time_offs:
                                print(toff)
                    search_start = False

            else:
                end = offs[off][1]
                if verbose > 1:
                    print("end",end,temp_var[end])
                if temp_var[end] >= temp_var_thresh_:
                    if verbose > 1:
                        print("above thresh")
                    if end + hwl <= n:
                        bpa = below_prop(temp_var[end:end+hwl],temp_var_thresh)
                        if bp_one_side:
                            bpa = below_prop(temp_var[end:end+hwl],temp_var_thresh)
                        else:
                            bpa = below_prop(temp_var[end-hhwl:end+hhwl],temp_var_thresh)

                        if end + 2*hwl <= n:
                            bpa2 = below_prop(temp_var[end:end+2*hwl],temp_var_thresh)
                        else:
                            bpa2 = below_prop(temp_var[end:n],temp_var_thresh)

                        if verbose > 1:
                            print("bpa",bpa)
                            print("bpa2",bpa2)

                        if (bpa <= bp_thresh):
                            end = end + np.argmax(temp_var[end:end+hwl+1])
                            new_offs[-1][1] = end
                            if verbose > 1:
                                print(new_offs)
                                if time_idx:
                                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                    for toff in time_offs:
                                        print(toff)
                            search_start = True
                            off += 1
                        else:
                            if off < num_offs-1:
                                next_start = offs[off+1][0]
                                on_length = next_start - end

                                skip_on = False
                                if skip_len_bp:
                                    if (on_length <= length_thresh) and (below_prop(act[end:next_start],act_thresh) > act_bp_ft):
                                        skip_on = True
                                else:
                                    if (on_length <= length_thresh):
                                        skip_on = True

                                if skip_on:
                                    offs = np.delete(offs,off,axis=0)
                                    num_offs -= 1
                                    if verbose > 1:
                                        print("delete")
                                else:
                                    bpb = below_prop(temp_var[end-hwl-1:end],temp_var_thresh)
                                    if verbose > 1:
                                        print("bpb",bpb)
                                    if bpb > bp_thresh:
                                        offs = np.delete(offs,off,axis=0)
                                        num_offs -= 1
                                        if verbose > 1:
                                            print("delete")
                                    else:
                                        new_offs[-1][1] = end-hwl-1 + np.argmax(temp_var[end-hwl-1:end])
                                        if verbose > 1:
                                            print(new_offs)
                                            if time_idx:
                                                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                                for toff in time_offs:
                                                    print(toff)
                                        search_start = True
                                        off += 1
                            else:
                                end = end + np.argmax(temp_var[end:n])
                                new_offs[-1][1] = end
                                if verbose > 1:
                                    print(new_offs)
                                    if time_idx:
                                        time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                        for toff in time_offs:
                                            print(toff)
                                search_start = True
                                off += 1
                    else:
                        if verbose > 1:
                            print("bpa",below_prop(temp_var[end:n],temp_var_thresh))

                        end = end + np.argmax(temp_var[end:n])
                        new_offs[-1][1] = end
                        if verbose > 1:
                            print(new_offs)
                            if time_idx:
                                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                for toff in time_offs:
                                    print(toff)
                        search_start = True
                        off += 1
                else:
                    if verbose > 1:
                        print("below thresh")

                    if verbose > 1:
                        if end + hwl <= n:
                            print("bpa",below_prop(temp_var[end:end+hwl],temp_var_thresh))
                            if end + 2*hwl <= n:
                                print("bpa2",below_prop(temp_var[end:end+2*hwl],temp_var_thresh))
                            else:
                                print("bpa2",below_prop(temp_var[end:n],temp_var_thresh))
                        else:
                            print("bpa",below_prop(temp_var[end:n],temp_var_thresh))

                    if off < num_offs-1:
                        next_start = offs[off+1][0]
                        on_length = next_start - end
                        skip_on = False
                        if skip_len_bp:
                            if (on_length <= length_thresh) and (below_prop(act[end:next_start],act_thresh) > act_bp_ft):
                                skip_on = True
                        else:
                            if (on_length <= length_thresh):
                                skip_on = True

                        if skip_on:
                            offs = np.delete(offs,off,axis=0)
                            num_offs -= 1
                            if verbose > 1:
                                print("delete")
                        else:
                            if verbose > 1:
                                print("searching peak")

                            i = end+1
                            discriminant_ok = end
                            peak_base = end
                            while i < next_start:
                                border_bool = False

                                if border == "disc":
                                    if discriminant[i]:
                                        border_bool = True
                                elif border == "mod":
                                    if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)):
                                        border_bool = True
                                elif border == "mod2":
                                    if discriminant[i] or ((temp[i] < temp_thresh) and (act_median[i] < 2*min_act)) or (act_median[i] == 0):
                                        border_bool = True

                                if border_bool:
                                    if temp_var[i] >= temp_var_thresh:
                                        peak_base = i
                                        i = next_start
                                    i += 1
                                else:
                                    discriminant_ok = i
                                    i = next_start

                            if discriminant_ok == end:
                                if peak_base > end:
                                    if verbose > 1:
                                        print("peak found")
                                    peak = peak_base+1
                                    while temp_var[peak] >= temp_var[peak-1]:
                                        peak += 1

                                    new_offs[-1][1] = peak
                                    if verbose > 1:
                                        print(new_offs)
                                        if time_idx:
                                            time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                            for toff in time_offs:
                                                print(toff)
                                    search_start = True
                                    off += 1
                                else:
                                    offs = np.delete(offs,off,axis=0)
                                    num_offs -= 1
                                    if verbose > 1:
                                        print("delete")

                            else:
                                if verbose > 1:
                                    print("peak not found, no discriminant")

                                new_offs[-1][1] = discriminant_ok
                                if verbose > 1:
                                    print(new_offs)
                                    if time_idx:
                                        time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                        for toff in time_offs:
                                            print(toff)
                                search_start = True
                                off += 1

                    else:
                        end = end + np.argmax(temp_var[end:n])
                        new_offs[-1][1] = end
                        if verbose > 1:
                            print(new_offs)
                            if time_idx:
                                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                                for toff in time_offs:
                                    print(toff)
                        search_start = True
                        off += 1

        num_offs = len(new_offs)
        props = np.array([below_prop(temp[o[0]:o[1]],temp_thresh) for o in new_offs])

        new_offs = np.array(new_offs)
        if verbose > 1:
            print("refined offs and props\n",new_offs)
            if time_idx:
                time_offs = [[time_index[new_offs[o][0]],time_index[new_offs[o][1]],props[o]] for o in range(num_offs)]
                for toff in time_offs:
                    print(toff)
            print("temp_bp_thresh",temp_bp_thresh)

        new_offs = new_offs[np.where(props >= temp_bp_thresh,True,False)].copy()
        num_offs = len(new_offs)
        if verbose > 1:
            print("temp filtered refined offs\n",new_offs)
            if time_idx:
                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                for toff in time_offs:
                    print(toff)

        if last_act_filt:
            act_bp = np.array([below_prop(act[o[0]:o[1]],act_thresh) for o in new_offs])
            off_len = np.array([o[1]-o[0] for o in new_offs])
            if just_bp:
                if verbose > 1:
                    print("filtered refined offs act_bp")
                    print("act_bp_ft",act_bp_ft)
                    if time_idx:
                        time_offs = [[time_index[new_offs[o][0]],time_index[new_offs[o][1]],off_len[o],act_bp[o]] for o in range(num_offs)]
                        for toff in time_offs:
                            print(toff)

                new_offs = new_offs[np.where(act_bp > act_bp_ft,True,False)].copy()

            else:
                act_zp = np.array([zero_prop(act[o[0]:o[1]]) for o in new_offs])
                if verbose > 1:
                    print("act_bp filtered refined offs",act_bp)
                    print("act_zp filtered refined offs",act_zp)
                new_offs = new_offs[np.where(np.logical_and(act_bp > act_bp_ft, act_zp > 0.7),True,False)].copy()

            num_offs = len(new_offs)
            if verbose > 1:
                print("act filtered refined offs\n",new_offs)
                if time_idx:
                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                    for toff in time_offs:
                        print(toff)

        if ltv_filt:
            tv = np.array([[temp_var[o[0]],temp_var[o[1]]] for o in new_offs])
            ltv = np.array([(o[0] > low_temp_var_thresh) and (o[1] > low_temp_var_thresh) for o in tv])
            ltv = np.where(ltv,True,False)
            if verbose > 1:
                print("temp_var_thresh",temp_var_thresh)
                print("low_temp_var_thresh",low_temp_var_thresh)
                print("tv\n",tv)
                print("ltv",ltv)


            new_offs = new_offs[ltv].copy()
            num_offs = len(new_offs)
            
            if verbose > 1:
                print("ltv_filt offs\n",new_offs)
                if time_idx:
                    time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                    for toff in time_offs:
                        print(toff)

        new_offs = np.array(new_offs)
        off_len = np.array([off[1]-off[0] for off in new_offs])
        if last_len_filt:
            new_offs = new_offs[np.where(off_len > min_off_length,True,False)].copy()
            num_offs = len(new_offs)
        off_len = np.array([off[1]-off[0] for off in new_offs])
        
        prefilt_nof = new_offs.copy()
        prefilt_report = off_report(new_offs,act,temp,temp_var,time_index,temp_thresh,act_thresh,extra=extra,lumus=lumus,nbins=7,verbose=False)
        if verbose > 1:
            print("prefilt offs")
            print(new_offs)
            if time_idx:
                time_offs = [[time_index[o[0]],time_index[o[1]]] for o in new_offs]
                for toff in time_offs:
                    print(toff)
        
        prefilt = np.ones(n)
        for off in new_offs:
            prefilt[off[0]:off[1]] = 0.0

        mask = np.full(n,True,dtype=bool)
        for o in range(num_offs):
            if off_len[o] >= 240:
                mask[new_offs[o][0]:new_offs[o][1]] = False
        valid_act = act[mask].copy()

        pad = np.max(act)*np.ones(sleep_filt_hws)
        actf = np.insert(valid_act,0,pad)
        actf = np.append(actf,pad)
        actf = median_filter(actf,sleep_filt_hws,padding='padded')

        if sleep_conf == "all":
            sleep_act_thresh = np.quantile(act,sleep_aqt,method=qt_method)
        elif sleep_conf == "zp":
            qt_act = zp_act + (1.0 - zp_act)*sleep_zqt
            sleep_act_thresh = np.quantile(act,qt_act,method=qt_method)
        elif sleep_conf == "both":
            if zp_act < sleep_aqt:
                sleep_act_thresh = np.quantile(act,sleep_aqt,method=qt_method)
                # print("full quantile")
            else:
                qt_act = zp_act + (1.0 - zp_act)*sleep_zqt
                sleep_act_thresh = np.quantile(act,qt_act,method=qt_method)
                # print("nonzero quantile")

        sleep_filt = np.where(actf > sleep_act_thresh, 1, 0)
        sleeps = zero_sequences(sleep_filt)
        sleep_len = np.array([s[1]-s[0] for s in sleeps])
        if short_slep_filt:
            sleeps = sleeps[np.where(sleep_len > 240,True,False)]
        sleep_filt = np.ones(len(sleep_filt))
        for s in sleeps:
            start = s[0]
            end = s[1]
            sleep_filt[start:end] = 0.0

        sleep_ = np.ones(n)
        sleep_[mask] = sleep_filt

        if ltbfilt:
            sleeps = zero_sequences(sleep_)
            for s in sleeps:
                start = s[0]
                end = s[1]

                while (start < n) and (temp[start] < temp_thresh):
                     sleep_[start] = 1.0
                     start += 1

                while (end < n) and (temp[end] < temp_thresh):
                     sleep_[end] = 1.0
                     end -= 1

        sleep_prop = np.array([zero_prop(sleep_[off[0]:off[1]]) for off in new_offs])
        # prefilt_report["sleep_prop"] = sleep_prop
        sleep_mask = np.where(sleep_prop < sleep_prop_max,True,False)
        for i in range(len(sleep_mask)):
            if not sleep_mask[i]:
                if lumus:
                    if cap_filt and prefilt_report.at[i,"dcv"] < 1.75e-4:
                         sleep_mask[i] = True
        sleep_new_offs = new_offs[sleep_mask].copy()
        deleted_sleep = 1-sleep_mask.astype(int)
        deleted_sleep = deleted_sleep.nonzero()[0]

        if sleep_filter:
            new_offs = sleep_new_offs.copy()
            num_offs = len(new_offs)

        filtered = np.ones(n)
        for off in new_offs:
            filtered[off[0]:off[1]] = 0.0

        zp = zero_prop(discriminant)
        ltp = below_prop(temp,temp_thresh)
        positive_act = act[np.where(act > 0,True,False)]
        low_act_ = below_prop(positive_act,min_act)
        if dev:
            print("offwrist proportion:",zero_prop(filtered))
            print("low disc proportion:",1-zp)
            print("low temp proportion:",ltp)
            print("low act:",low_act_)

        temp_mean = np.mean(temp)

        low_act = False
        bimodal = True
        if ((len(positive_act)/n) < 0.1) or (low_act_ > 0.8):
            bimodal = False
            low_act = True
            if verbose:
                print("low act")
        else:
            if ash_d <= ash_min:
                bimodal = False

            else:  
                if ash_d < ash_max:
                    if (temp_thresh > temp_mean): # and (ltp > 0.5):
                        bimodal = False

        if bimodal:
            if verbose:
                print("bimodal")
            refined = filtered.copy()

        else:
            if verbose:
                print("unimodal")
            if low_act or (zp < cap_zp_thresh):
                new_offs = [[0,n]]
                if verbose:
                    print("all off")
            else:
                if verbose:
                    print("all on")
                new_offs = []
            refined = np.ones(n)
            for off in new_offs:
                refined[off[0]:off[1]] = 0.0
            new_offs = np.array(new_offs)

        num_offs = len(new_offs)
        
        bf = new_offs.copy()
        # if verbose:
        #     print("report before filter")
        report = off_report(new_offs,act,temp,temp_var,time_index,temp_thresh,act_thresh,extra=extra,lumus=lumus,nbins=7,verbose=False)
        sleep_report = off_report(sleep_new_offs,act,temp,temp_var,time_index,temp_thresh,act_thresh,extra=extra,lumus=lumus,nbins=7,verbose=False)

        num_report = len(report)

        off_mask = []
        deleted = []
        if num_offs > 0:
            for o in range(num_report):
                ofm = True
                if (report.at[o,"len"] < 240):
                    if ((report.at[o,"act_bd"] < 0.35) and (report.at[o,"tv_bd"] < 0.35)):
                        ofm = False
                    if (report.at[o,"zp"] < 0.35):
                        ofm = False
                    if act_border_filt and ((report.at[o,"acta"] < 0.2) and (report.at[o,"actb"] < 0.2)):
                        ofm = False
                    if ((report.at[o,"acta"] < 0.1) or (report.at[o,"actb"] < 0.1)) and ((report.at[o,"act_bd"] < 0.5) and (report.at[o,"tv_bd"] < 0.5)):
                        ofm = False
                    if (dtm_filt and (report.at[o,"dtm"] > 1.0)):
                        ofm = False

                off_mask.append(ofm)

            off_mask = np.array(off_mask)

            deleted = 1-off_mask.astype(int)
            deleted = deleted.nonzero()[0]

            rid = report.index.to_numpy()
            filtered_report = report.loc[rid[off_mask]]
            filtered_report.index = np.arange(len(filtered_report))
        else:
            filtered_report = report.copy()

        if verbose:
            print("deleted_sleep",deleted_sleep)
            print("deleted",deleted)
            # print("filtered")
            # print(filtered_report)

        nof = new_offs[off_mask].copy()
        if bimodal and report_filt:
            new_offs = nof.copy()
            num_offs = len(new_offs)

            refined = np.ones(n)
            for off in new_offs:
                refined[off[0]:off[1]] = 0.0

        if sleep_filter and bimodal and ((len(true) > 0) and (len(sleep) > 0)):
            acc,sss,spp,precision,on_detect,off_detect,over_found,over_found_sleep,long_detection,ofs_location,of_location = scores(true,prefilt,states=sleep,ofs_locate=True,long_event=240)

            prefilt_nof = prefilt_nof.tolist()
            sleep_new_offs = sleep_new_offs.tolist()
            nof = nof.tolist()

            prefilt_report["over"] = False
            prefilt_report["sleep"] = False
            numr = len(prefilt_report)
            for offnum in range(numr):
                off = prefilt_nof[offnum]
                if 1-zero_prop(true[off[0]:off[1]]) > 0.4:
                    prefilt_report.at[offnum,"over"] = True
                    if 1-zero_prop(sleep[off[0]:off[1]]) > 0.4:
                        prefilt_report.at[offnum,"sleep"] = True

            deleted_sleep_okay = []
            for d in deleted_sleep:
                if not prefilt_report.at[d,"over"]:
                    deleted_sleep_okay.append(d)

            num_over = len(prefilt_report[prefilt_report["over"] == True])
            num_over_sleep = len(prefilt_report[prefilt_report["sleep"] == True])
            num_okay = numr - num_over

            sleep_report["over"] = False
            sleep_report["sleep"] = False
            numr = len(sleep_report)
            for offnum in range(numr):
                off = sleep_new_offs[offnum]
                if 1-zero_prop(true[off[0]:off[1]]) > 0.4:
                    sleep_report.at[offnum,"over"] = True
                    if 1-zero_prop(sleep[off[0]:off[1]]) > 0.4:
                        sleep_report.at[offnum,"sleep"] = True

            deleted_okay = []
            for d in deleted:
                if not sleep_report.at[d,"over"]:
                    deleted_okay.append(d)

            num_over_ = len(sleep_report[sleep_report["over"] == True])
            num_over_sleep_ = len(sleep_report[sleep_report["sleep"] == True])
            num_okay_ = numr - num_over_ 

            delta_over = num_over - num_over_
            delta_over_sleep = num_over_sleep - num_over_sleep_
            delta_okay = num_okay - num_okay_

            filtered_report["over"] = False
            filtered_report["sleep"] = False
            numr = len(nof)
            for offnum in range(numr):
                off = nof[offnum]
                if 1-zero_prop(true[off[0]:off[1]]) > 0.4:
                    filtered_report.at[offnum,"over"] = True
                    if 1-zero_prop(sleep[off[0]:off[1]]) > 0.4:
                        filtered_report.at[offnum,"sleep"] = True

            print("deleted_sleep_okay",deleted_sleep_okay)
            print("deleted_okay",deleted_okay)

            print("prefilt_report")
            print(prefilt_report)
            print("sleep_report")
            print(sleep_report)
            print("filtered_report")
            print(filtered_report)

            print("num_over", num_over)
            print("num_over_sleep", num_over_sleep)
            print("num_okay", num_okay)
            print("num_over_", num_over_)
            print("num_over_sleep_", num_over_sleep_)
            print("num_okay_", num_okay_)

            sleep_new_offs = np.array(sleep_new_offs)
            nof = np.array(nof)

        # plt.figure()
        # plt.subplot(211)
        # plt.plot(act,color="blue",label="act")
        # plt.plot(np.max(act)*sleep_,color="red",label="sleep")
        # plt.plot(np.max(act)*prefilt,color="green",label="off")
        # plt.legend()
        # plt.subplot(212)
        # plt.plot(valid_act,color="blue",label="act")
        # plt.plot(actf,color="yellow",label="actf")
        # plt.plot(np.max(valid_act)*sleep_filt,color="red",label="sleep")
        # plt.legend()
        # plt.show()

    else:
        refined = np.ones(n)
        filtered = refined.copy()
        bimodal = False
        ltp = 0.0

    if dev:
        return refined, filtered, bimodal, ltp, prefilt_report, sleep_report, filtered_report, 1-sleep_, delta_over, delta_over_sleep, delta_okay

        # if len(bf) > 0 and len(new_offs) > 0:
        #     return refined, filtered, bimodal, ltp, filtered_report, report, bf.tolist(), new_offs.tolist()
        # elif len(bf) > 0:
        #     return refined, filtered, bimodal, ltp, filtered_report, report, bf.tolist(), new_offs
        # elif en(new_offs) > 0:
        #     return refined, filtered, bimodal, ltp, filtered_report, report, bf, new_offs.tolist()
        # else:
        #     return refined, filtered, bimodal, ltp, filtered_report, report, bf, new_offs
    else:
        return refined