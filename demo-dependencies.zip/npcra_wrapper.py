import pandas as pd
from npcra_functions import *

def npcra_wrapper(df, index="DATE/TIME", activity="PIM", state="STATE"):
    time_index = df[index]
    if not isinstance(time_index[0],datetime):
        if isinstance(time_index[0],str):
            time_index = pd.to_datetime(time_index,dayfirst=True)
    df[index] = time_index

    df = df.loc[:,[index,activity,state]]

    df.set_index(df[index], inplace = True)
    ldays = actigraphy_split_by_day(df, start_hour = 0)
    
    result_df = pd.DataFrame()
    M10_list = []
    M10_onset_list = []
    L5_list = []
    L5_onset_list = []
    IV_list = []
    IS_list = []
    for d in ldays['DATAFRAME']:
        L5, L5_onset = actigraphy_calculate_L5(d,activity,state=state)
        M10, M10_onset = actigraphy_calculate_M10(d,activity,state=state)

        M10_list.append(M10)
        M10_onset_list.append(M10_onset)
        L5_list.append(L5)
        L5_onset_list.append(L5_onset)
        
    result_df['M10'] = M10_list
    result_df['M10_onset'] = M10_onset_list
    result_df['L5'] = L5_list
    result_df['L5_onset'] = L5_onset_list
    result_df['DAY'] = ldays['DAY']
    result_df.set_index('DAY', inplace=True)

    avg_day = actigraphy_calculate_average_day(df, 60, state=state)

    first_day = avg_day
    second_day = avg_day.copy()
    second_day.index += pd.Timedelta(days = 1)
    two_average_day = pd.concat([first_day,second_day],axis=0)
    AVG_L5, AVG_L5_onset = actigraphy_calculate_L5(two_average_day,activity,state=state)
    AVG_M10, AVG_M10_onset = actigraphy_calculate_M10(two_average_day,activity,state=state)

    return actigraphy_calculate_IV(df,activity,state=state),actigraphy_calculate_IS(df,activity,state=state),AVG_L5,AVG_L5_onset,AVG_M10, AVG_M10_onset,result_df