import pandas as pd
import numpy as np

def actigraphy_split_by_day(df, start_hour = 0):
    ldays = []
    ldays_ref = []
    
    #First day is the start of the day of the first Epoch
    sdate = pd.Timestamp(year = df.index[0].year, month = df.index[0].month, day = df.index[0].day)
    if(df.index[0].hour <= start_hour):
        sdate = sdate - pd.Timedelta(hours = start_hour) 
    else:
        sdate = sdate + pd.Timedelta(hours = start_hour)         
    
    while sdate < df.index[-1]:
        day = np.logical_and(df.index >= sdate, df.index < sdate + pd.Timedelta(hours = 24))
        ldays.append(df[day])
        ldays_ref.append(pd.Timestamp(year = sdate.year, month = sdate.month, day = sdate.day))
        sdate += pd.Timedelta(hours = 24)
    days_df = pd.DataFrame()
    days_df['DAY'] = ldays_ref
    days_df['DATAFRAME'] = ldays

    return days_df

def actigraphy_calculate_L5(df_in, channel, remove_offwrist = True):
    df = df_in.copy()
    if(remove_offwrist):
        df[df['STATE']== 4] = np.nan
    i = 0
    start = df.index[i]
    end = start + pd.Timedelta(hours = 5)
    L5 = np.inf
    L5_onset = df.index[0]
    while end <= df.index[-1] and i < len(df):

        index = np.logical_and(df.index>=start, df.index < end)
        five_hours_average = np.nanmean(df[index][channel])
        if five_hours_average < L5:
            L5 = five_hours_average
            L5_onset = start
        i += 1
        start = df.index[i]
        end = start + pd.Timedelta(hours = 5)
    return L5, L5_onset

def actigraphy_calculate_M10(df_in, channel, remove_offwrist = True):
    df = df_in.copy()
    if(remove_offwrist):
        df[df['STATE']== 4] = np.nan
    i = 0
    start = df.index[i]
    end = start + pd.Timedelta(hours = 10)
    M10 = 0
    M10_onset = df.index[0]
    while end <= df.index[-1] and i < len(df):
        index = np.logical_and(df.index>=start, df.index < end)
        ten_hours_average = np.nanmean(df[index][channel])
        if ten_hours_average > M10:
            M10 = ten_hours_average
            M10_onset = start
        i += 1
        start = df.index[i]
        end = start + pd.Timedelta(hours = 10)
    return M10, M10_onset

def actigraphy_calculate_IV(df_in, channel, remove_offwrist = True):
    df = df_in.copy()
    if(remove_offwrist):
        df[df['STATE']== 4] = np.nan
    ldf = df.copy()
    ldf['HOUR'] = ldf.index.hour
    ldf['DAY'] = ldf.index.date
    sumdf = ldf.groupby(['DAY', 'HOUR']).mean()
    diffval = sumdf[channel].diff().dropna()
    muldiff = diffval.multiply(diffval).sum()*len(sumdf)
    diffvalden = sumdf[channel]-sumdf[channel].mean()
    muldiffden = diffvalden.multiply(diffvalden).sum()*(len(sumdf)-1)
    
    return muldiff/muldiffden

def actigraphy_calculate_IS(df_in, channel, remove_offwrist = True):
    df = df_in.copy()
    if(remove_offwrist):
        df[df['STATE']== 4] = np.nan
    ldf = df.copy()
    ldf['HOUR'] = ldf.index.hour
    ldf['DAY'] = ldf.index.date
    sumdfhour = ldf.groupby(['HOUR']).mean()
    sumdf = ldf.groupby(['DAY', 'HOUR']).mean()
    num = sumdfhour[channel] - sumdf[channel].mean()
    mulnum = num.multiply(num).sum()*len(sumdf)
    den = sumdf[channel] - sumdf[channel].mean()
    mulden = den.multiply(den).sum()*len(sumdfhour)

    return mulnum/mulden

def actigraphy_calculate_average_day(df, epoch):
    resample_df = df.resample(str(epoch)+'S').mean()
    resample_df['HOUR'] = resample_df.index.hour
    resample_df['DAY'] = resample_df.index.date
    resample_df['SECOND'] = resample_df.index.second
    resample_df['MINUTE'] = resample_df.index.minute
    avg_day = resample_df.groupby(['HOUR', 'MINUTE', 'SECOND']).mean()
    H = avg_day.index.get_level_values(0).to_numpy()
    M = avg_day.index.get_level_values(1).to_numpy()
    S = avg_day.index.get_level_values(2).to_numpy()
    avg_day['AVGTIME'] = pd.to_datetime(H*3600+M*60+S,unit='s')
    avg_day.set_index('AVGTIME', inplace = True)
    return avg_day

def npcra_wrapper(df, index="DATE/TIME"):
    df.set_index( df[index], inplace = True)
    ldays = actigraphy_split_by_day(df, start_hour = 0)

    result_df = pd.DataFrame()
    M10_list = []
    M10_onset_list = []
    L5_list = []
    L5_onset_list = []
    IV_list = []
    IS_list = []
    for d in ldays['DATAFRAME']:
        avg_day = actigraphy_calculate_average_day(df, 60)

        first_day = avg_day
        second_day = avg_day.copy()
        second_day.index += pd.Timedelta(days = 1)
        two_average_day = first_day.append(second_day)

        L5, L5_onset = actigraphy_calculate_L5(two_average_day,'PIM')
        M10, M10_onset = actigraphy_calculate_M10(two_average_day,'PIM')

        M10_list.append(M10)
        M10_onset_list.append(M10_onset)
        L5_list.append(L5)
        L5_onset_list.append(L5_onset)

        IV_list.append(actigraphy_calculate_IV(d,'PIM'))
        IS_list.append(actigraphy_calculate_IS(d,'PIM'))
        
    result_df['M10'] = M10_list
    result_df['M10_onset'] = M10_onset_list
    result_df['L5'] = L5_list
    result_df['L5_onset'] = L5_onset_list
    result_df['IV'] = IV_list
    result_df['IS'] = IS_list
    result_df['DAY'] = ldays['DAY']
    result_df.set_index('DAY', inplace=True)

    return result_df