import pandas as pd
import numpy as np
from datetime import date,datetime,timedelta,time

def actigraphy_split_by_day(df, start_hour = 0):
    ldays = []
    ldays_ref = []
    
    #First day is the start of the day of the first Epoch
    sdate = pd.Timestamp(year = df.index[0].year, month = df.index[0].month, day = df.index[0].day)
    if(df.index[0].hour <= start_hour):
        sdate = sdate - pd.Timedelta(hours = start_hour) 
    else:
        sdate = sdate + pd.Timedelta(hours = start_hour)         
    
    while sdate < df.index[-1]:
        day = np.logical_and(df.index >= sdate, df.index < sdate + pd.Timedelta(hours = 24))
        ldays.append(df[day])
        ldays_ref.append(pd.Timestamp(year = sdate.year, month = sdate.month, day = sdate.day))
        sdate += pd.Timedelta(hours = 24)
    days_df = pd.DataFrame()
    days_df['DAY'] = ldays_ref
    days_df['DATAFRAME'] = ldays

    return days_df

def actigraphy_calculate_L5(df_in, channel, remove_offwrist=True, state="STATE"):
    df = df_in.copy()
    if(remove_offwrist):
        df[df[state]== 4] = np.nan
    i = 0
    start = df.index[i]
    end = start + pd.Timedelta(hours = 5)
    L5 = np.inf
    L5_onset = df.index[0]
    while end <= df.index[-1] and i < len(df):

        index = np.logical_and(df.index>=start, df.index < end)
        five_hours_average = np.nanmean(df[index][channel])
        if five_hours_average < L5:
            L5 = five_hours_average
            L5_onset = start
        i += 1
        start = df.index[i]
        end = start + pd.Timedelta(hours = 5)

    df = 0

    return L5, L5_onset

def actigraphy_calculate_M10(df_in, channel, remove_offwrist=True, state="STATE"):
    df = df_in.copy()
    if(remove_offwrist):
        df[df[state]== 4] = np.nan
    i = 0
    start = df.index[i]
    end = start + pd.Timedelta(hours = 10)
    M10 = 0
    M10_onset = df.index[0]
    while end <= df.index[-1] and i < len(df):
        index = np.logical_and(df.index>=start, df.index < end)
        ten_hours_average = np.nanmean(df[index][channel])
        if ten_hours_average > M10:
            M10 = ten_hours_average
            M10_onset = start
        i += 1
        start = df.index[i]
        end = start + pd.Timedelta(hours = 10)

    df = 0 

    return M10, M10_onset

def actigraphy_calculate_IV(df, channel, remove_offwrist = True, state="STATE"):
    if(remove_offwrist):
        df[df[state]== 4] = np.nan

    ldf = df.copy()
    ldf['HOUR'] = ldf.index.hour
    ldf['DAY'] = ldf.index.date
    sumdf = ldf.groupby(['DAY', 'HOUR']).mean()
    diffval = sumdf[channel].diff().dropna()
    muldiff = diffval.multiply(diffval).sum()*len(sumdf)
    diffvalden = sumdf[channel]-sumdf[channel].mean()
    muldiffden = diffvalden.multiply(diffvalden).sum()*(len(sumdf)-1)

    ldf = 0
    sumdf = 0
    diffval = 0
    diffvalden = 0
    
    return muldiff/muldiffden

def actigraphy_calculate_IS(df, channel, remove_offwrist = True, state="STATE"):
    if(remove_offwrist):
        df[df[state]== 4] = np.nan
    ldf = df.copy()
    ldf['HOUR'] = ldf.index.hour
    ldf['DAY'] = ldf.index.date
    sumdfhour = ldf.groupby(['HOUR']).mean()
    sumdf = ldf.groupby(['DAY', 'HOUR']).mean()
    num = sumdfhour[channel] - sumdf[channel].mean()
    mulnum = num.multiply(num).sum()*len(sumdf)
    den = sumdf[channel] - sumdf[channel].mean()
    mulden = den.multiply(den).sum()*len(sumdfhour)

    ldf = 0
    sumdfhour = 0
    sumdf = 0
    num = 0
    den = 0

    return mulnum/mulden

def actigraphy_calculate_average_day(df,epoch=60,remove_offwrist=True,state="STATE"):
    resample_df = df.copy()

    if(remove_offwrist):
        resample_df[resample_df[state]== 4] = np.nan
        resample_df = resample_df.dropna()

    # from functools import partial

    # from pandas.tseries.frequencies import to_offset

    # def rounding(t, freq):
    #     freq = to_offset(freq)
    #     return pd.Timestamp((t.value // freq.delta.value) * freq.delta.value)

    resample_df = resample_df.resample(str(epoch)+'S').mean()
    
    # resample_df = resample_df.groupby(partial(rounding, freq=str(epoch)+'S')).mean()
    # print(resample_df)
    # resample_df.to_csv("resample_df_1.csv")

    resample_df['HOUR'] = resample_df.index.hour
    resample_df['DAY'] = resample_df.index.date
    resample_df['SECOND'] = resample_df.index.second
    resample_df['MINUTE'] = resample_df.index.minute

    # print(resample_df)

    # import dask.dataframe as dd
    # resample_df = dd.from_pandas(resample_df,npartitions=1000) 
    # # print(resample_df)

    # avg_day = resample_df.groupby(['HOUR','MINUTE','SECOND'],observed=True).mean().compute()
    avg_day = resample_df.groupby(['HOUR','MINUTE','SECOND']).mean()
    resample_df = 0

    H = avg_day.index.get_level_values(0).to_numpy()
    M = avg_day.index.get_level_values(1).to_numpy()
    S = avg_day.index.get_level_values(2).to_numpy()

    avg_day['AVGTIME'] = pd.to_datetime(H*3600+M*60+S,unit='s')
    avg_day.set_index('AVGTIME', inplace = True)

    avg_day.to_csv("avg_day.csv")

    return avg_day

def actigraphy_calculate_SRI(df,low=0.0,high=1.0,epoch=60,remove_offwrist=True,state="STATE",sleep="STATE"):
    if sleep != state:
        avg_sleep = actigraphy_calculate_average_day(df.loc[:,[sleep,state]],epoch=epoch,state="state")[sleep].to_numpy()
    else:
        avg_sleep = actigraphy_calculate_average_day(df.loc[:,[state]],epoch=epoch,state="state")[sleep].to_numpy()

    SRI = np.sum(np.where(np.logical_or(avg_sleep <= low,avg_sleep >= high),1,0))/len(avg_sleep)

    return SRI

def npcra_wrapper(df, index="DATE/TIME", activity="PIM", state="STATE"):
    time_index = df[index]
    if not isinstance(time_index[0],datetime):
        if isinstance(time_index[0],str):
            time_index = pd.to_datetime(time_index,dayfirst=True)
    df[index] = time_index

    df = df.loc[:,[index,activity,state]]

    df.set_index(df[index], inplace = True)
    ldays = actigraphy_split_by_day(df, start_hour = 0)
    
    # print(df)

    result_df = pd.DataFrame()
    M10_list = []
    M10_onset_list = []
    L5_list = []
    L5_onset_list = []
    IV_list = []
    IS_list = []
    for d in ldays['DATAFRAME']:
        L5, L5_onset = actigraphy_calculate_L5(d,activity,state=state)
        M10, M10_onset = actigraphy_calculate_M10(d,activity,state=state)

        M10_list.append(M10)
        M10_onset_list.append(M10_onset)
        L5_list.append(L5)
        L5_onset_list.append(L5_onset)
        
    result_df['M10'] = M10_list
    result_df['M10_onset'] = M10_onset_list
    result_df['L5'] = L5_list
    result_df['L5_onset'] = L5_onset_list
    result_df['DAY'] = ldays['DAY']
    result_df.set_index('DAY', inplace=True)

    print("avg")
    avg_day = actigraphy_calculate_average_day(df, 60, state=state)

    first_day = avg_day
    second_day = avg_day.copy()
    second_day.index += pd.Timedelta(days = 1)
    two_average_day = pd.concat([first_day,second_day],axis=0)
    print("l5")
    AVG_L5, AVG_L5_onset = actigraphy_calculate_L5(two_average_day,activity,state=state)
    print("m10")
    AVG_M10, AVG_M10_onset = actigraphy_calculate_M10(two_average_day,activity,state=state)
    print("return")

    return actigraphy_calculate_IV(df,activity,state=state),actigraphy_calculate_IS(df,activity,state=state),AVG_L5,AVG_L5_onset,AVG_M10, AVG_M10_onset,result_df