# -*- coding: utf-8 -*-

# Logistic Regression model: algorithm - 17/12/2019
# Julius Andretti

import sys,inspect,os,joblib
import time as ttime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn import preprocessing

# import jax.numpy as jnp

folder = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
root = folder[0:(len(folder)-len("pylogit"))]

from functions import *

class LogReg:
    def __init__(self,activity,cut=0.02496,half_window_length=np.arange(0,30,dtype=int),start_column=0,in_bed=None,shift=0,verbose=False,nproll=True,column_prefix="",variables=["act","std","mean","median","max","zp","full_zp"]):
        self.initStart = ttime.time()
        self.cutoff = cut # Probability threshold

        max_window_length = half_window_length[-1]

        # Data processing
        start = ttime.time()

        activity = np.array(activity)
        
        n = activity.shape[0] # Number of points

        act0 = activity[0]
        actn = activity[n-1]

        if in_bed is None:
            for x in range(max_window_length):
                activity = np.insert(activity,0,act0) # 1s inserted at the beggining
                activity = np.append(activity,actn)   # 1s inserted at the end

            loop_start = max_window_length
            loop_end = n+max_window_length

            self.raw_activity = activity[loop_start:loop_end].copy()
            self.normalized_activity = activity[loop_start:loop_end].copy()

            off,on = 0,n
            self.lights_off = off
            self.lights_on = on

        else:
            self.in_bed = in_bed
            edges = np.concatenate(([0],np.diff(in_bed)))
            edges_idx = edges.nonzero()[0]
            edges_num = [edges[i] for i in edges_idx]
            num_edges = len(edges_idx)

            if num_edges == 2:
                off,on = edges_idx
            elif num_edges == 1:
                if edges_idx[0] < n-edges_idx[0]:
                    off,on = edges_idx[0],n
                else:
                    off,on = 0,edges_idx[0]
            elif num_edges == 0:
                off,on = 0,n
            else:
                up = [edges_idx[h] for h in range(num_edges) if edges_num[h] > 0]
                down = [edges_idx[h] for h in range(num_edges) if edges_num[h] < 0]

                off = up[0]
                on = down[-1]
                
            off += shift
            on += shift

            if off < max_window_length:
                for x in range(max_window_length-off):
                    activity = np.insert(activity,0,act0) # 1s inserted at the beggining
                loop_start = max_window_length

            else:
                loop_start = off

            if on == n-1:
                on = n            

            if on+max_window_length > n:
                for x in range(on+max_window_length-n):
                    activity = np.append(activity,actn)
                loop_end = len(activity)-max_window_length

            else:
                loop_end = on
                loop_end += loop_start - off

            self.lights_off = off
            self.lights_on = on
             
            if verbose:
                print("borders")
                print(n)
                print(edges_idx)
                print(off,on)
                print(loop_start,loop_end)
                print(len(activity))
                print("")
            
            self.raw_activity = activity[loop_start:loop_end].copy()
            self.normalized_activity = activity[loop_start:loop_end].copy()

        n = len(self.normalized_activity)

        # Data calculated and read will be stored into a DataFrame
        start = ttime.time()
        names = []
        if "act" in variables:
            names = ['activity',]   

        if "full_zp" in variables:
            names.append("full_zp")

        for i in half_window_length:
            if "mean" in variables:
                names.append('meanb_w='+str(2*i+1))

            if "median" in variables:
                names.append('medianb_w='+str(2*i+1))

            if "std" in variables:
                names.append('stdb_w='+str(2*i+1))

            if "var" in variables:
                names.append('varb_w='+str(2*i+1))

            if "max" in variables:
                names.append('maxb_w='+str(2*i+1))

            if "zp" in variables:
                names.append('zpa_w='+str(2*i+1))

        names = [column_prefix+name for name in names]
        
        data = pd.DataFrame([])

        column = start_column
        if "act" in variables:
            data[column_prefix+"activity"] = self.raw_activity.copy()
            column += 1

        if "full_zp" in variables:
           data[column_prefix+"full_zp"] = zero_prop(self.raw_activity)
           column += 1

        for window in half_window_length:
            if nproll:
                rolled = rolling_window(activity[loop_start-window:loop_end+window], 2*window+1)
            else:
                rolled = pd.Series(activity[loop_start-window:loop_end+window]).rolling(2*window+1,center=True)

            if "mean" in variables:
                if nproll:
                    data[column_prefix+'mean_w='+str(2*window+1)] = np.mean(rolled, axis=-1)
                else:
                    data[column_prefix+'mean_w='+str(2*window+1)] = rolled.mean().to_numpy()

            if "median" in variables:
                if nproll:
                    data[column_prefix+'median_w='+str(2*window+1)] = np.median(rolled, axis=-1)
                else:
                    data[column_prefix+'median_w='+str(2*window+1)] = rolled.median().to_numpy()

            if "std" in variables:
                if nproll:
                    data[column_prefix+'std_w='+str(2*window+1)] = np.std(rolled, axis=-1)
                else:
                    data[column_prefix+'std_w='+str(2*window+1)] = rolled.std().to_numpy()

            if "var" in variables:
                if nproll:
                    data[column_prefix+'var_w='+str(2*window+1)] = np.var(rolled, axis=-1)
                else:
                    data[column_prefix+'var_w='+str(2*window+1)] = rolled.var().to_numpy()
                column += 1

            if "max" in variables:
                if nproll:
                    data[column_prefix+'max_w='+str(2*window+1)] = np.max(rolled, axis=-1)
                else:
                    data[column_prefix+'max_w='+str(2*window+1)] = rolled.max().to_numpy()
                column += 1

            if "zp" in variables:
                if nproll:
                    data[column_prefix+'zp_w='+str(2*window+1)] = zp_axis(rolled)
                else:
                    data[column_prefix+'zp_w='+str(2*window+1)] = rolled.apply(zero_prop,raw=True).to_numpy()
                column += 1

        end = ttime.time()
        self.timeDF = (end-start)

        self.half_window_length = half_window_length
        self.variableNames = names
        self.n = n
        self.data = data
        self.initEnd = ttime.time()
        self.timeInit = self.initEnd - self.initStart

    def model(self,previous=[],newState=1):
        start = ttime.time()
        dirpath = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        self.logRegModel = joblib.load(dirpath+'/logregmodel.sav') # Loads logistic regression model
        self.pcaModel = joblib.load(dirpath+'/pcamodel.sav') # Loas PCA decomposition model
        end = ttime.time()
        self.timeLoad = (end-start)

        start = ttime.time()
        self.scaled = preprocessing.scale(self.data) # Data needs to be properly scaled (mean=0,var=1) before being fed to the PCA decomposition
        self.transformed = self.pcaModel.transform(self.scaled) # PCA decomposition of data
        probability = np.transpose(np.array([self.logRegModel.predict_proba([self.transformed[i]]) for i in range(len(self.transformed))]))[0][0] # Probabilities obtained using logistic regression

        if len(previous)==0:
            previous=np.zeros(self.n)
            
        result = np.zeros(self.n)
        for i in range(self.n):
            if probability[i] <= self.cutoff:
                result[i] = 1

        states = previous.copy()
        for i in range(self.n):
            if result[i] == 1:
                states[i] = newState

        self.states = states
        self.proba = proba
        end = ttime.time()
        self.timeModel = (end-start)
        self.totTime = self.timeInit + self.timeModel

    def plotStates(self):
        plt.figure()
        plt.plot(self.states)
        plt.xlabel('Epochs')
        plt.ylabel('States')
        plt.show()

    def printTimes():
        print('Time spent loading models:',self.timeLoad)
        print('Time spent calculating:',self.timeCalc)
        print('Time spent creating dataframe:',self.timeDF)
        print('Time spent scaling, transforming and scoring:',self.timeModel)
        print('Total time:', self.totTime)