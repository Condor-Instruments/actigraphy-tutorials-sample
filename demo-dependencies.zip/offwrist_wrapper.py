import sys
import inspect
import os

import pandas as pd
import xgboost as xgb
import numpy as np

from scipy.ndimage import binary_closing, binary_opening

from functions import *

folder = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

from logreg import LogReg

n_estimators = 80
max_depth = 6

xg_reg = xgb.XGBClassifier(objective='binary:logistic',
                                   max_delta_step=1,
                                   min_child_weight=10,
                                   # colsample_bytree=0.3,
                                   # scale_pos_weight=12,
                                   grow_policy="lossguide",
                                   learning_rate=0.05,
                                   max_depth=max_depth, 
                                   alpha=10, 
                                   n_estimators=n_estimators,
                                   eval_metric="auc",
                                   )
xg_reg.load_model(folder+"/model_full_n=80_d=6.json")

mwl = 11
cutoff = 0.75

def offwrist_wrapper(df):
    act = df["activity"].to_numpy()

    lg = LogReg(act,max_window_length=mwl)
    data = lg.data

    int_temp = df["int_temp"].to_numpy()
    ext_temp = df["ext_temp"].to_numpy()

    lg = LogReg(int_temp,max_window_length=mwl,column_prefix='temp_',variables=["std",
                                                                                # "mean",
                                                                                # "median",
                                                                                # "max",
                                                                                # "zp",
                                                                                 "full_zp",
                                                                                ])
    data = pd.concat([data,lg.data],axis=1)
    
    diff = np.diff(np.concatenate(([0],int_temp)))
    me_diff = mean_filter(diff,2,padding="same")

    data["diff_temp"] = np.abs(me_diff)

    data["dif_temp"] = np.absolute(np.subtract(int_temp,ext_temp))
    data["ext_temp"] = ext_temp

    prob = xg_reg.predict_proba(data)[:,0]

    out = np.where(prob >= cutoff,1,0)

    strel = np.ones(12)   # Morphological strutcturing element
    out_morph = binary_opening(binary_closing(out,strel),strel).astype(int)

    n = len(out_morph)

    edges = np.concatenate(([0],np.diff(out_morph)))
    edges_index = edges.nonzero()[0]
    transitions = [[k,edges[k]] for k in edges_index]

    if len(transitions) > 0:
        if transitions[0][1] > 0:
            transitions.insert(0,[0,-1])

        if transitions[-1][1] < 0:
            transitions.append([n,1])

    offs = [[],[]]
    for transition in transitions:
        if transition[1] < 0:
            offs[0].append(transition[0])

        elif transition[1] > 0:
            offs[1].append(transition[0])

    offs = np.transpose(offs)
    num_offs = len(offs)

    out_filt = np.zeros(n)

    if num_offs > 0:
        fullzp = below_prop(act,0)
        thresh = np.percentile(act,round(100*(fullzp+(1-fullzp)*0.33)))
        
        remove = []
        for j in range(num_offs):
            begin = offs[j,0]
            end = offs[j,1]
            zp = below_prop(act[begin:end],0)

            if zp < 0.75:
                remove.append(j)
        offs = np.delete(offs,remove,axis=0)

        num_offs = len(offs)

        out_filt = np.zeros(n)
        if num_offs > 0:
            for off in offs:
                out_filt[off[0]:off[1]] = 4

            wl = 180
            num_offs = len(offs)
            remove = []
            for j in range(num_offs):
                begin = offs[j,0]
                end = offs[j,1]

                length = end - begin

                if j == 0:
                    end_below_prop = below_prop(act[end:end+wl],thresh)
                    end_on_prop = below_prop(out_filt[end:end+wl],0)

                    if begin-wl >= 0:
                        begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                        begin_on_prop = below_prop(out_filt[begin-wl:begin],0)
                    else:
                        begin_below_prop = below_prop(act[0:begin],thresh)
                        begin_on_prop = below_prop(out_filt[0:begin],0)                            
                    

                elif j == num_offs-1:
                    begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                    begin_on_prop = below_prop(out_filt[begin-wl:begin],0)

                    if end+wl <= n:
                        end_below_prop = below_prop(act[end:end+wl],thresh)
                        end_on_prop = below_prop(out_filt[end:end+wl],0)
                    else:
                        end_below_prop = below_prop(act[end:n],thresh)
                        end_on_prop = below_prop(out_filt[end:n],0)

                else:
                    begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                    end_below_prop = below_prop(act[end:end+wl],thresh)

                    begin_on_prop = below_prop(out_filt[begin-wl:begin],0)
                    end_on_prop = below_prop(out_filt[end:end+wl],0)


                if (begin_below_prop > 0.6) or (end_below_prop > 0.6):
                    if length <= 60:
                        if (begin_on_prop > 0.8) and (end_on_prop > 0.8):
                            remove.append(j)

            offs = np.delete(offs,remove,axis=0)
            # print(offs)
            # print("")

            num_offs = len(offs)

            out_filt = np.zeros(n)
            if num_offs > 0:
                for off in offs:
                    out_filt[off[0]:off[1]] = 4

                edges = np.concatenate(([0],np.diff(out_filt)))
                edges_index = edges.nonzero()[0]
                transitions = [[k,edges[k]] for k in edges_index]

                if len(transitions) > 0:
                    if transitions[0][1] > 0:
                        transitions.insert(0,[0,-1])

                    if transitions[-1][1] < 0:
                        transitions.append([n,1])

                ons = [[],[]]
                for transition in transitions:
                    if transition[1] < 0:
                        ons[0].append(transition[0])

                    elif transition[1] > 0:
                        ons[1].append(transition[0])

                ons = np.transpose(ons)

                # print(offs,"\n",ons)

                wl = 120
                num_ons = len(ons)
                remove = []
                for j in range(num_ons):
                    begin = ons[j,0]
                    end = ons[j,1]

                    length = end - begin

                    if j == 0:
                        off_before_start = 0
                        off_after_end = ons[j+1,0]

                        end_on_prop = below_prop(out_filt[end:end+wl],0)

                        if begin-wl >= 0:
                            begin_on_prop = below_prop(out_filt[begin-wl:begin],0)
                        else:
                            begin_on_prop = below_prop(out_filt[0:begin],0)                            
                        

                    elif j == num_ons-1:
                        off_before_start = ons[j-1,1]
                        off_after_end = n

                        begin_on_prop = below_prop(out_filt[begin-wl:begin],0)

                        if end+wl <= n:
                            end_on_prop = below_prop(out_filt[end:end+wl],0)
                        else:
                            end_on_prop = below_prop(out_filt[end:n],0)

                    else:
                        off_before_start = ons[j-1,1]
                        off_after_end = ons[j+1,0]

                        begin_on_prop = below_prop(out_filt[begin-wl:begin],0)
                        end_on_prop = below_prop(out_filt[end:end+wl],0)


                    if (begin_on_prop == 0.0) and (end_on_prop == 0.0):
                        remove.append(j)

                    # else:
                    #     if (off_after_end-off_before_start-length) > length 

                ons = np.delete(ons,remove,axis=0)

                # print(ons)

                out_filt = 4*np.ones(n)
                for on in ons:
                    out_filt[on[0]:on[1]] = 0

    return out_filt