# -*- coding: utf-8 -*-

# Crespo algorithm: helping functions - 2021
# Julius Andretti

import numpy as np
import pandas as pd
from datetime import date,datetime,timedelta,time
from scipy.signal import find_peaks as peak

def datetime_diff(stamps):
    datetime_diff = np.array([(stamps[i]-stamps[i-1]).total_seconds() for i in range(1,len(stamps))])
    datetime_diff = np.insert(datetime_diff,0,[0])
    return datetime_diff

def to_datetime(date):
    """
    Converts a numpy datetime64 object to a python datetime object 
    Input:
      date - a np.datetime64 object
    Output:
      DATE - a python datetime object
    """
    timestamp = ((date - np.datetime64('1970-01-01T00:00:00'))
                 / np.timedelta64(1, 's'))
    return datetime.utcfromtimestamp(timestamp)

# Scales input to be in the [-1,1] interval 
def scale_by_max(signal,scale=None):
    # signal is the input data

    if scale is None:   # Data is divided by its largest value
        factor = 1.0/np.max(np.absolute(signal))
    else:   # Data is the divided by given scalar
        factor = 1.0/scale
    return factor*np.array(np.absolute(signal))


def fftf(signal,epoch_time=60,cut_d=0,cut_h=0,cut_m=0):
    n = len(signal)
    total_time = n*epoch_time
    
    fourier_coef = np.fft.rfft(signal)
    f = len(fourier_coef)

    cut_d = int(86400*cut_d)
    cut_h = int(3600*cut_h)
    cut_m = int(60*cut_m)
    cut_time = cut_d + cut_h + cut_m

    cut_index = int(round(total_time/cut_time))+1

    filtered = np.fft.irfft(fourier_coef[0:cut_index],n)

    # print(n)
    # print(total_time)
    # print(cut_time)

    return filtered

def get_peak(signal,center,valley=False,peak_hws=10):
    if (center-peak_hws) >= 0:
        if (center+peak_hws+1) <= len(signal):
            peak_search = signal[center-peak_hws:center+peak_hws+1]
        else:
            peak_search = signal[center-peak_hws:len(signal)]
    else:
        peak_search = signal[0:center+peak_hws+1]

    if valley:
        peak = np.argmin(peak_search)
    else:
        peak = np.argmax(peak_search)
    
    return peak_search[peak]

def median_filter(signal,hws,padding='same'):
    # signal is the input vector
    # hws is the filter half-window length, i.e hws = 1, window_indexes = [center-1,center,center+1]
    
    n = len(signal)
    if padding == "same":
        pad = np.zeros(hws)
        filt = np.insert(np.array(signal).copy(),0,pad)
        filt = np.append(filt,pad)
        filt = pd.Series(filt).rolling(2*hws+1,center=True).median().to_numpy()[hws:(n+hws)]

    elif padding == "padded":
        n -= 2*hws
        filt = pd.Series(np.array(signal)).rolling(2*hws+1,center=True).median().to_numpy()[hws:(n+hws)]

    return np.array(filt)

def zero_prop(a):
    n = len(a)
    return  np.sum(np.where(a == 0,1,0))/n

def zero_prop_filter(signal,hws,padding='same'):
    # signal is the input vector
    # hws is the filter half-window length, i.e hws = 1, window_indexes = [center-1,center,center+1]
    
    n = len(signal)
    if padding == "same":
        pad = np.zeros(hws)
        filt = np.insert(np.array(signal).copy(),0,pad)
        filt = np.append(filt,pad)
        filt = pd.Series(filt).rolling(2*hws+1,center=True).apply(zero_prop,raw=True).to_numpy()[hws:(n+hws)]

    elif padding == "padded":
        n -= 2*hws
        filt = pd.Series(np.array(signal)).rolling(2*hws+1,center=True).apply(zero_prop,raw=True).to_numpy()[hws:(n+hws)]

    return np.array(filt)

def make_transitions_df(window,median,metric,bedtime):
    window_len = len(window)
    columns = ["class","start","end","length","mean","median","zero_proportion","abvm_proportion"]
    transitions_df = pd.DataFrame()
    
    if bedtime:
        thresholded = np.where(median <= metric, True, False)   # Thresholding operation for bed timestamps
    else:
        thresholded = np.where(median >= metric, True, False)   # Thresholding operation for getup time
    t = 0
    while t < window_len:
        if thresholded[t]:
            start = t

            t += 1
            while (t < window_len) and (thresholded[t]):
                t += 1
            end = t
            
            if bedtime:
                slice_class = "v"
            else:
                slice_class = "p"
        else:
            start = t

            t += 1
            while (t < window_len) and (not thresholded[t]):
                t += 1
            end = t

            if bedtime:
                slice_class = "p"
            else:
                slice_class = "v"

        sliced = window[start:end]
        slice_len = end-start
        slice_mean = np.mean(sliced)
        slice_median = np.median(sliced)
        slice_zeros = sum(np.where(sliced == 0,1,0))/(end-start)
        slice_abvm = sum(np.where(sliced > metric,1,0))/(end-start)
        dictionary = {"class":slice_class,
                "start":start,
                "end":end,
                "length":slice_len,
                "mean":slice_mean,
                "median":slice_median,
                "zero_proportion":slice_zeros,
                "abvm_proportion":slice_abvm,}
        transitions_df = pd.concat([transitions_df,pd.DataFrame(dictionary,index=[0])],axis=0,ignore_index=True)


    return transitions_df.reindex(columns=columns)


def seq_len_filt(seq_min,seq,filt_class="v",metric=0.5):
    n = len(seq)

    window = np.zeros(n)
    base_transitions = make_transitions_df(window,seq,metric,False)

    num_transitions_window = len(base_transitions)

    output = np.ones(n)

    if num_transitions_window > 1:
        if (base_transitions.at[0,"length"] <= seq_min) and (base_transitions.at[0,"class"] == filt_class):
            start = int(base_transitions.at[0,"start"])
            end = int(base_transitions.at[1,"end"])

            base_transitions.at[1,"start"] = start

            slice_len = end-start
            base_transitions.at[1,"length"] = slice_len

            base_transitions.drop(index=[0],inplace=True)
            num_transitions_window = len(base_transitions)
            base_transitions.index = range(num_transitions_window)


        t = 1
        while (t < num_transitions_window):
            remove = False

            if (base_transitions.at[t,"length"] <= seq_min) and (base_transitions.at[t,"class"] == filt_class):
                remove = True

            if remove:
                # Transition filtering process takes place
                start = int(base_transitions.at[t-1,"start"])

                if t < num_transitions_window-1:
                    end = int(base_transitions.at[t+1,"end"])
                    base_transitions.drop(index=[t,t+1],inplace=True)

                else:
                    end = int(base_transitions.at[t,"end"])
                    base_transitions.drop(index=[t],inplace=True)

                base_transitions.at[t-1,"end"] = end

                slice_len = end-start
                base_transitions.at[t-1,"length"] = slice_len

                num_transitions_window = len(base_transitions)
                base_transitions.index = range(num_transitions_window)

            else:
                t += 1


        num_transitions_window = len(base_transitions)
        t = 0
        while (t < num_transitions_window):
            if (base_transitions.at[t,"class"] == "v"):
                output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
            t += 1

        base_transitions = make_transitions_df(window,output,metric,False)
        num_transitions_window = len(base_transitions)

        if num_transitions_window > 1:
            if (base_transitions.at[0,"length"] <= seq_min) and (base_transitions.at[0,"class"] == filt_class):
                start = int(base_transitions.at[0,"start"])
                end = int(base_transitions.at[1,"end"])

                base_transitions.at[1,"start"] = start

                slice_len = end-start
                base_transitions.at[1,"length"] = slice_len

                base_transitions.drop(index=[0],inplace=True)
                num_transitions_window = len(base_transitions)
                base_transitions.index = range(num_transitions_window)


            t = 1
            while (t < num_transitions_window):
                remove = False

                if (base_transitions.at[t,"length"] <= seq_min) and (base_transitions.at[t,"class"] == filt_class):
                    remove = True

                if remove:
                    # Transition filtering process takes place
                    start = int(base_transitions.at[t-1,"start"])

                    if t < num_transitions_window-1:
                        end = int(base_transitions.at[t+1,"end"])
                        base_transitions.drop(index=[t,t+1],inplace=True)

                    else:
                        end = int(base_transitions.at[t,"end"])
                        base_transitions.drop(index=[t],inplace=True)

                    base_transitions.at[t-1,"end"] = end

                    slice_len = end-start
                    base_transitions.at[t-1,"length"] = slice_len

                    num_transitions_window = len(base_transitions)
                    base_transitions.index = range(num_transitions_window)

                else:
                    t += 1

            output = np.ones(n)
            num_transitions_window = len(base_transitions)
            t = 0
            while (t < num_transitions_window):
                if (base_transitions.at[t,"class"] == "v"):
                    output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
                t += 1

    elif num_transitions_window == 1:
        output = seq

    return output


def zp_filt(zp_min,seq,filt_class="v",metric=0.5):
    n = len(seq)

    window = np.zeros(n)
    base_transitions = make_transitions_df(window,seq,metric,False)

    num_transitions_window = len(base_transitions)

    output = np.ones(n)

    if num_transitions_window > 1:
        if (base_transitions.at[0,"zero_proportion"] <= zp_min) and (base_transitions.at[0,"class"] == filt_class):
            start = int(base_transitions.at[0,"start"])
            end = int(base_transitions.at[1,"end"])

            base_transitions.at[1,"start"] = start

            slice_len = end-start
            base_transitions.at[1,"length"] = slice_len

            base_transitions.drop(index=[0],inplace=True)
            num_transitions_window = len(base_transitions)
            base_transitions.index = range(num_transitions_window)


        t = 1
        while (t < num_transitions_window):
            remove = False

            if (base_transitions.at[t,"zero_proportion"] <= zp_min) and (base_transitions.at[t,"class"] == filt_class):
                remove = True

            if remove:
                # Transition filtering process takes place
                start = int(base_transitions.at[t-1,"start"])

                if t < num_transitions_window-1:
                    end = int(base_transitions.at[t+1,"end"])
                    base_transitions.drop(index=[t,t+1],inplace=True)

                else:
                    end = int(base_transitions.at[t,"end"])
                    base_transitions.drop(index=[t],inplace=True)

                base_transitions.at[t-1,"end"] = end

                slice_len = end-start
                base_transitions.at[t-1,"length"] = slice_len

                num_transitions_window = len(base_transitions)
                base_transitions.index = range(num_transitions_window)

            else:
                t += 1


        num_transitions_window = len(base_transitions)
        t = 0
        while (t < num_transitions_window):
            if (base_transitions.at[t,"class"] == "v"):
                output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
            t += 1

        base_transitions = make_transitions_df(window,output,metric,False)
        num_transitions_window = len(base_transitions)

        if num_transitions_window > 1:
            if (base_transitions.at[0,"zero_proportion"] <= zp_min) and (base_transitions.at[0,"class"] == filt_class):
                start = int(base_transitions.at[0,"start"])
                end = int(base_transitions.at[1,"end"])

                base_transitions.at[1,"start"] = start

                slice_len = end-start
                base_transitions.at[1,"length"] = slice_len

                base_transitions.drop(index=[0],inplace=True)
                num_transitions_window = len(base_transitions)
                base_transitions.index = range(num_transitions_window)


            t = 1
            while (t < num_transitions_window):
                remove = False

                if (base_transitions.at[t,"zero_proportion"] <= zp_min) and (base_transitions.at[t,"class"] == filt_class):
                    remove = True

                if remove:
                    # Transition filtering process takes place
                    start = int(base_transitions.at[t-1,"start"])

                    if t < num_transitions_window-1:
                        end = int(base_transitions.at[t+1,"end"])
                        base_transitions.drop(index=[t,t+1],inplace=True)

                    else:
                        end = int(base_transitions.at[t,"end"])
                        base_transitions.drop(index=[t],inplace=True)

                    base_transitions.at[t-1,"end"] = end

                    slice_len = end-start
                    base_transitions.at[t-1,"length"] = slice_len

                    num_transitions_window = len(base_transitions)
                    base_transitions.index = range(num_transitions_window)

                else:
                    t += 1

            output = np.ones(n)
            num_transitions_window = len(base_transitions)
            t = 0
            while (t < num_transitions_window):
                if (base_transitions.at[t,"class"] == "v"):
                    output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
                t += 1

    elif num_transitions_window == 1:
        output = seq

    return output

def surround_filt(seq_min,window,median,filt_class="p",metric=0.5,bedtime=False):
    n = len(window)

    base_transitions = make_transitions_df(window,median,metric,bedtime)
    num_transitions_window = len(base_transitions)

    output = np.ones(n)

    if num_transitions_window > 2:
        t = 1
        while (t < num_transitions_window):
            remove = False

            if (base_transitions.at[t,"class"] == filt_class):
                if (t < num_transitions_window-1):
                    if (
                        (base_transitions.at[t,"length"] < seq_min) 
                        and
                        (
                          (base_transitions.at[t,"length"] <= base_transitions.at[t-1,"length"])
                          and
                          (base_transitions.at[t,"length"] <= base_transitions.at[t+1,"length"])
                        )
                       ):
                        remove = True

            if remove:
                # Transition filtering process takes place
                start = int(base_transitions.at[t-1,"start"])

                if t < num_transitions_window-1:
                    end = int(base_transitions.at[t+1,"end"])
                    base_transitions.drop(index=[t,t+1],inplace=True)

                else:
                    end = int(base_transitions.at[t,"end"])
                    base_transitions.drop(index=[t],inplace=True)

                base_transitions.at[t-1,"end"] = end

                slice_len = end-start
                base_transitions.at[t-1,"length"] = slice_len

                num_transitions_window = len(base_transitions)
                base_transitions.index = range(num_transitions_window)

            else:
                t += 1

        t = 0
        while (t < num_transitions_window):
            if (base_transitions.at[t,"class"] == "v"):
                output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
            t += 1

        base_transitions = make_transitions_df(window,output,metric,bedtime)
        num_transitions_window = len(base_transitions)

        if num_transitions_window > 1:
            t = 1
            while (t < num_transitions_window):
                remove = False

                if (base_transitions.at[t,"class"] == filt_class):
                    if (t < num_transitions_window-1):
                        if (
                            (base_transitions.at[t,"length"] < seq_min) 
                            and
                            (
                              (base_transitions.at[t,"length"] <= base_transitions.at[t-1,"length"])
                              and
                              (base_transitions.at[t,"length"] <= base_transitions.at[t+1,"length"])
                            )
                           ):
                            remove = True

                if remove:
                    # Transition filtering process takes place
                    start = int(base_transitions.at[t-1,"start"])

                    if t < num_transitions_window-1:
                        end = int(base_transitions.at[t+1,"end"])
                        base_transitions.drop(index=[t,t+1],inplace=True)

                    else:
                        end = int(base_transitions.at[t,"end"])
                        base_transitions.drop(index=[t],inplace=True)

                    base_transitions.at[t-1,"end"] = end

                    slice_len = end-start
                    base_transitions.at[t-1,"length"] = slice_len

                    num_transitions_window = len(base_transitions)
                    base_transitions.index = range(num_transitions_window)

                else:
                    t += 1


            output = np.ones(n)
            t = 0
            while (t < num_transitions_window):
                if (base_transitions.at[t,"class"] == "v"):
                    output[int(base_transitions.at[t,"start"]):int(base_transitions.at[t,"end"])] = 0
                t += 1

    elif num_transitions_window > 0:
        output = median

    return output